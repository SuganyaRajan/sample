﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Xml;

namespace SmartXtract.Common
{
    public class ProcessData
    {
        #region Declaration
        String sLogPath = String.Empty;
        Boolean bResultFlag = true;
        string sWIPPath = string.Empty;
        string sReason = string.Empty;
        XmlDocument LoanTemplate = new XmlDocument();
        #endregion

        #region BindNodewithDOM
        public void BindNodewithDOM(XmlNode Node, long Top, long Left, long Right, long Bottom, string ImageName, XmlNamespaceManager nsmgr, int NodeIteration)
        {
            if (Node != null)
            {
                if (Node.NodeType == XmlNodeType.Element)
                {
                    if (Node.HasChildNodes)
                    {
                        int childcount = 0;
                        foreach (XmlNode ChildNode in Node.ChildNodes)
                        {
                            int PageIndex = 0;
                            long ChildTop = 0;
                            long ChildLeft = 0;
                            long ChildRight = 0;
                            long ChildBottom = 0;
                            XmlNode SelectionLineNode = null;
                            string NodeLineval = GetAttribute(ChildNode, "addData:BlockRef");
                            if (NodeLineval != "")
                            {
                                //XmlNamespaceManager nsMgr = new XmlNamespaceManager();
                                SelectionLineNode = ChildNode.SelectSingleNode(@"//addData:Blocks[@Id=""" + NodeLineval + @"""]//addData:Rect", nsmgr);
                                XmlNode SelectionIndex = ChildNode.SelectSingleNode(@"//addData:Blocks[@Id=""" + NodeLineval + @"""]", nsmgr);
                                if (SelectionIndex != null)
                                {
                                    PageIndex = Convert.ToInt32(SelectionIndex.FirstChild.Attributes.GetNamedItem("PageIndex").Value);
                                }
                            }
                            //Find Co-Ordinates
                            if (SelectionLineNode != null)
                            {

                                ChildTop = Convert.ToInt64(GetAttribute(SelectionLineNode, "Top"));
                                ChildLeft = Convert.ToInt64(GetAttribute(SelectionLineNode, "Left"));
                                ChildRight = Convert.ToInt64(GetAttribute(SelectionLineNode, "Right"));
                                ChildBottom = Convert.ToInt64(GetAttribute(SelectionLineNode, "Bottom"));
                            }
                            BindNodewithDOM(ChildNode, ChildLeft, ChildTop, ChildRight, ChildBottom, ImageName, nsmgr, NodeIteration + childcount);
                            childcount++;
                        }
                        XmlNode FindNode = LoanTemplate.SelectSingleNode(@"//node()[@id=""" + Node.Name + @"""]");
                        //XmlNode FindTextNode = LoanTemplate.SelectSingleNode(@"//node()[@id=""" + Node.Name + @"""]");
                        var FindTextNode = LoanTemplate.SelectSingleNode(@"//node()[@id=""txt" + Node.Name + @"""]");
                        if (FindNode != null)
                        {
                            string TypeAttribute = "";
                            if (FindNode.Attributes.GetNamedItem("Type") != null)
                            {
                                TypeAttribute = FindNode.Attributes.GetNamedItem("Type").Value;
                            }
                            if (TypeAttribute == "")
                            {
                                FindNode.InnerText = Node.InnerText;
                                if (FindTextNode != null)
                                {
                                    FindTextNode.Attributes["value"].Value = Node.InnerText;
                                    FindTextNode.Attributes["onclick"].Value = "SetImageCropping(" + Left + "," + Top + "," + Right + "," + Bottom + ",'" + ImageName + "');";
                                    string id = Node.Name;
                                    FindTextNode.Attributes["onchange"].Value = "SetText('#txt" + id + "','#" + id + "');";
                                }
                            }
                            else
                            {
                                XmlNode tr = LoanTemplate.CreateElement("tr");
                                int i = 0;
                                foreach (XmlNode LineChildNode in Node.ChildNodes)
                                {
                                    //XmlNode td = LoanTemplate.CreateElement("td");
                                    //td.InnerText = LineChildNode.InnerText;
                                    //tr.AppendChild(td);
                                    XmlNode td = LoanTemplate.CreateElement("td");
                                    //Create an input type dynamically.
                                    var element = LoanTemplate.CreateElement("input");
                                    //Assign different attributes to the element.
                                    element.SetAttribute("type", "text");
                                    element.SetAttribute("value", LineChildNode.InnerText);
                                    string id = LineChildNode.Name.Replace(" ", "") + NodeIteration + i;
                                    element.SetAttribute("id", "txt" + id);
                                    //element.SetAttribute("onclick", "SetImageCropping('"+Top+"','"+Left+ "','" + Right + "','" + Bottom + "','" + Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"Tif",ImageName).Replace("\\","\\\\") + "');");
                                    element.SetAttribute("onclick", "SetImageCropping('" + Left + "','" + Top + "','" + Right + "','" + Bottom + "','" + ImageName + "');");
                                    element.SetAttribute("onchange", "SetText('#txt" + id + "','#lbl" + id + "');");
                                    element.SetAttribute("class", "autohidetextboxvisible col form-control");
                                    var lbl = LoanTemplate.CreateElement("label");
                                    lbl.SetAttribute("id", "lbl" + id);
                                    lbl.SetAttribute("style", "display:none;");
                                    lbl.InnerText = LineChildNode.InnerText;
                                    td.AppendChild(element);
                                    td.AppendChild(lbl);
                                    tr.AppendChild(td);
                                    i++;
                                }
                                if (tr.HasChildNodes)
                                {
                                    FindNode.AppendChild(tr);
                                    if (FindTextNode != null)
                                        FindTextNode.AppendChild(tr);
                                }
                            }
                        }
                        else
                        {

                        }
                    }
                    else
                    {

                    }
                }
            }
        }
        #endregion

        #region GetAttribute
        public static String GetAttribute(XmlNode SelectNode, String AttrName)
        {
            String sReturn = "";
            try
            {
                if (SelectNode != null)
                {

                    if (SelectNode.Attributes.GetNamedItem(AttrName) != null)
                    {
                        return SelectNode.Attributes.GetNamedItem(AttrName).Value;
                    }
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            return sReturn;
        }
        #endregion

        #region ProcessTextPdfDOMData
        public void ProcessTextPdfDOMData(String LogTxt)
        {
            try
            {
                 
            }
            catch (Exception ex)
            {
                bResultFlag = false;
                sReason += "General Error in [WriteStatusLog]" + Environment.NewLine + ex.Message + Environment.NewLine;
                WriteLog("Error!! " + sReason);
            } 
        }
        #endregion

        #region TemplateTableCreation
        public static string CreateHTMLTemplateTable(string strTableName)
        {
            var table = new HtmlTable();
            var outTable = new StringBuilder();
            string html;
             
            HtmlTableRow row;
            HtmlTableCell cell;

             
            row = new HtmlTableRow();
            cell = new HtmlTableCell();
            cell.InnerText = "";
            row.Cells.Add(cell);
            cell.InnerText = "";
            row.Cells.Add(cell);
            cell.InnerText = "";
            row.Cells.Add(cell);
            table.Rows.Add(row);
             
            
            using (var sw = new StringWriter())
            {
                table.RenderControl(new HtmlTextWriter(sw));
                html = sw.ToString();
            }

            outTable.AppendFormat(html);
            return outTable.ToString();
        }
        #endregion

        #region WriteLog
        public Boolean WriteLog(String LogTxt)
        {
            try
            {
                ReadAppConfig();
                string strPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "ErrorLOG");
                if (!Directory.Exists(strPath))
                    Directory.CreateDirectory(strPath);
                 
                System.IO.StreamWriter oLog;
                if (System.IO.File.Exists(strPath +  DateTime.Today.ToShortDateString().Replace("/", "").ToString() + "_Log.txt") == false)
                {
                    oLog = new System.IO.StreamWriter(strPath  + DateTime.Today.ToShortDateString().Replace("/", "").ToString() + "_Log.txt", true);
                    oLog.WriteLine(LogTxt);
                    oLog.Close();
                    oLog.Dispose();
                }
                else
                {
                    oLog = new System.IO.StreamWriter(strPath + DateTime.Today.ToShortDateString().Replace("/", "").ToString() + "_Log.txt", true);
                    oLog.WriteLine(LogTxt);
                    oLog.Close();
                    oLog.Dispose();
                }
            }
            catch (Exception ex)
            {
                bResultFlag = false;
                sReason += "General Error in [WriteStatusLog]" + Environment.NewLine + ex.Message + Environment.NewLine;
                //WriteMessage("     Error!! " + sReason, "Error", Color.Red, 0);
                return false;
            }
            return true;
        }
        #endregion

        #region ReadAppConfig
        /// <summary>
        /// ReadAppConfig
        /// </summary>
        /// <param name=""></param>
        /// <returns></returns>
        private Boolean ReadAppConfig()
        {
            try
            {
                string sAppPath = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
                //String sAppPath = System.IO.Path.GetDirectoryName(Application.ExecutablePath);
                try
                {
                    sLogPath = ConfigurationManager.AppSettings["slogPath"].ToString();

                }
                catch
                {
                    sLogPath = System.IO.Path.Combine(sAppPath, "log");
                }


                return true;
            }
            catch (Exception ex)
            {
                bResultFlag = false;
                sReason += "General error in [ReadAppConfig]" + Environment.NewLine + ex.Message + Environment.NewLine;
                return bResultFlag;
            }
        }
        #endregion
    }
}