﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Data.Sql; 
using System.Linq;
using System.Web;

namespace SmartXtract.Common
{
    public class clsConnection
    {
        string conString = string.Empty;
        public clsConnection()
        {
            conString = ConfigurationManager.ConnectionStrings["ConString"].ToString();
        }
        public string UpdatateOcrdata(string accountno, string newbalance, string minpaydue, string payduedate, string address, string name,
            string streetline, string city, string state, string zip, string status, string pagetype, int result)
        {
            string retStr = "";

            try
            {
                SqlConnection con = new SqlConnection(conString);
                con.Open();

                SqlCommand cmd = new SqlCommand("sp_Genesis_InsertOcrData", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@TEMPLATENAME", null);
                cmd.Parameters.AddWithValue("@PAGETYPE", pagetype);
                cmd.Parameters.AddWithValue("@FILENAME", null);
                cmd.Parameters.AddWithValue("@FILEPATH", null);
                cmd.Parameters.AddWithValue("@USERNAME", null);
                cmd.Parameters.AddWithValue("@ACCOUNTNO", accountno);
                cmd.Parameters.AddWithValue("@ADDRESS", address);
                cmd.Parameters.AddWithValue("@NEWBALANCE", newbalance);
                cmd.Parameters.AddWithValue("@MINIMUMPAYMENTDUE", minpaydue);
                cmd.Parameters.AddWithValue("@PAYMENTDUEDATE", payduedate);
                cmd.Parameters.AddWithValue("@NAME", name);
                cmd.Parameters.AddWithValue("@STREETLINE", streetline);
                cmd.Parameters.AddWithValue("@COUNTRY", null);
                cmd.Parameters.AddWithValue("@CITY", city);
                cmd.Parameters.AddWithValue("@STATE", state);
                cmd.Parameters.AddWithValue("@ZIPCODE", zip);
                cmd.Parameters.AddWithValue("@retID", result);
                cmd.Parameters.AddWithValue("@STATUS", status);

                int ret = cmd.ExecuteNonQuery();

                retStr = "success";

            }
            catch (Exception ex)
            {
                retStr = "error";
            }
            return retStr;
        }

        public DataSet RetrieveOcrData(string accountno)
        {
            DataSet ds = new DataSet();

            try
            {
                SqlConnection con = new SqlConnection(conString);
                con.Open();

                SqlCommand cmd = new SqlCommand("sp_Genesis_RetrieveOcrData", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@AccountNumber", accountno);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                con.Close();
                cmd.Dispose();
                da.Dispose();

            }
            catch (Exception ex)
            {
                ds = null;
            }
            return ds;
        }
        public DataSet RetrieveCoOrdinates(string accountno)
        {
            DataSet ds = new DataSet();

            try
            {
                SqlConnection con = new SqlConnection(conString);
                con.Open();

                SqlCommand cmd = new SqlCommand("sp_Genesis_RetrieveCoOrdinates", con);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@AccountNumber", accountno);
                SqlDataAdapter da = new SqlDataAdapter(cmd);
                da.Fill(ds);
                con.Close();
                cmd.Dispose();
                da.Dispose();

            }
            catch (Exception ex)
            {
                ds = null;
            }
            return ds;
        }
    }
}