﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using SmartXtract.OCRProcess;
using SmartXtract.FineReaderService;
using System.Drawing;
using System.Xml;
using System.Configuration;
using System.IO;
//using System.Windows.Forms;

namespace SmartXtract.Common
{
    public class Transform
    {

        String sLogPath = String.Empty;
        Boolean bResultFlag = true;
        string sWIPPath = string.Empty;
        string sReason = string.Empty;

        enum Format
        {
            XML,
            txt,
            pdf,
            xlsx,
            doc,

        }

        [System.Web.Services.WebMethod]
        public Boolean ConvertFile(string Inputpath, string Outputpath, string sproject, string ProjectName)
        {
            Boolean breturnflag = true;
            String sDesFile = string.Empty;
            String sNewDir = System.IO.Path.Combine(System.IO.Path.GetDirectoryName(Outputpath), @"Backup\" + Guid.NewGuid().ToString());
            if (!System.IO.Directory.Exists(sNewDir))
            {
                System.IO.Directory.CreateDirectory(sNewDir);
            }

            foreach (String sSourceFile in System.IO.Directory.GetFiles(Outputpath))
            {
                sDesFile = System.IO.Path.Combine(sNewDir, System.IO.Path.GetFileName(sSourceFile));
                try
                {


                    System.IO.File.Move(sSourceFile, sDesFile);
                }

                catch (Exception ex)
                {

                    Console.WriteLine(ex.Message);
                }
            }

            breturnflag = OCRRequest(Inputpath, Outputpath, sproject, ProjectName);
            return breturnflag;
        }

        private Boolean OCRRequest(String Input, String Output, string sproject, string ProjectName)
        {
            try
            {

                OCRProcess.Service1Client OCRClient = new OCRProcess.Service1Client();

                try
                {
                    String Response;
                    if (!System.IO.Directory.Exists(Output))
                        System.IO.Directory.CreateDirectory(Output);
                    if (ProjectName.ToUpper() == "ARGO")
                    {
                        Response = OCRClient.DoIdentifyOcr(Input, Output, sproject);
                    }
                    else
                    {
                        //Response = OCRClient.DoOCRProcess(Input, Output);//, sproject);
                        Response = OCRClient.DoOCR(Input, Output, sproject);
                    }
                    return true;
                }
                catch (Exception ex)
                {
                    // MessageBox.Show("Error in extraction process " + ex.Message, GenericClass.MsgTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //Console.WriteLine(ex.Message);
                    return false;
                }
            }
            catch (Exception WebException)
            {
                //MessageBox.Show("Error in extraction process " + WebException.StackTrace.ToString() + Environment.NewLine + WebException.Message, GenericClass.MsgTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                //Console.WriteLine(ex.Message);
                return false;
            }
        }
        public Boolean OCRFRPRocess(String Input, String Output)
        {
            try
            {
                Input = System.IO.Path.GetDirectoryName(Input);
                FineReaderService.Service1Client OCRClient = new FineReaderService.Service1Client();
                try
                {

                    String Response;

                    if (!System.IO.Directory.Exists(Output))
                        System.IO.Directory.CreateDirectory(Output);
                    Response = OCRClient.DoOCR(Input, Output, enumFormat.TXT);


                    return true;
                }
                catch (Exception ex)
                {
                    // MessageBox.Show("Error in extraction process " + ex.Message, GenericClass.MsgTitle, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    //Console.WriteLine(ex.Message);
                    return false;
                }
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        #region WriteStatusLog
        public Boolean WriteStatusLog(String LogTxt)
        {
            try
            {
                ReadAppConfig();
                if (!System.IO.Directory.Exists(sLogPath))
                {
                   System.IO.Directory.CreateDirectory(sLogPath);
                }
                System.IO.StreamWriter oLog;
                if (System.IO.File.Exists(sLogPath + "\\FomRIG" + DateTime.Today.ToShortDateString().Replace("/", "").ToString() + "_Log.txt") == false)
                {
                    oLog = new System.IO.StreamWriter(sLogPath + "\\FomRIG" + DateTime.Today.ToShortDateString().Replace("/", "").ToString() + "_Log.txt", true);
                    oLog.WriteLine(LogTxt);
                    oLog.Close();
                    oLog.Dispose();
                }
                else
                {
                    oLog = new System.IO.StreamWriter(sLogPath + "\\FomRIG" + DateTime.Today.ToShortDateString().Replace("/", "").ToString() + "_Log.txt", true);
                    oLog.WriteLine(LogTxt);
                    oLog.Close();
                    oLog.Dispose();
                }
            }
            catch (Exception ex)
            {
                bResultFlag = false;
                sReason += "General Error in [WriteStatusLog]" + Environment.NewLine + ex.Message + Environment.NewLine;
                //WriteMessage("     Error!! " + sReason, "Error", Color.Red, 0);
                return false;
            }
            return true;
        }
        #endregion


        #region ReadAppConfig
        /// <summary>
        /// ReadAppConfig
        /// </summary>
        /// <param name=""></param>
        /// <returns></returns>
        private Boolean ReadAppConfig()
        {
            try
            {
                string sAppPath = System.IO.Path.GetDirectoryName(System.Reflection.Assembly.GetExecutingAssembly().Location);
                //String sAppPath = System.IO.Path.GetDirectoryName(Application.ExecutablePath);
                try
                {
                    sLogPath = ConfigurationManager.AppSettings["slogPath"].ToString();

                }
                catch
                {
                    sLogPath = System.IO.Path.Combine(sAppPath, "log");
                }


                return true;
            }
            catch (Exception ex)
            {
                bResultFlag = false;
                sReason += "General error in [ReadAppConfig]" + Environment.NewLine + ex.Message + Environment.NewLine;
                return bResultFlag;
            }
        }
        #endregion

      

    }
}