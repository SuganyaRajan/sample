﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace SmartXtract.Common
{
    public class Common
    {
        public static string Parse(string source)
        {
            var numbers = new[] { '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' };
            var chars = new[] { '.', ',', '-', '+' };

            return new string(source
                               .Where(x => numbers.Contains(x) || chars.Contains(x))
                               .ToArray()).Trim(chars);
        }

        //public static int userID
        //{
        //    get { return session["customerID"] == null ? -1 : (int)session["customerID"]; }
        //    set { session["customerID"] = value; }
        //}

        //public static int userName
        //{
        //    get { return session["customerID"] == null ? -1 : (int)session["customerID"]; }
        //    set { session["customerID"] = value; }
        //}

        //private int userid;
        //public static int UserId
        //{
        //    get
        //    {
        //        return userid;
        //    }
        //    set
        //    {
        //        userid = value;
        //    }
        //}


        private string username;
        public  string UserName
        {
            get
            {
                return username;
            }
            set
            {
                username = value;
            }
        }

        

    }
}