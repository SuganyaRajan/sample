﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace SmartXtract.Controllers
{
    public class HomeController : Controller
    {
        public static SmartXtract_User GlobalUser;
        public static SmartXtract_UserLog GlobalUserLog;

        public ActionResult Index()
        {
            GlobalUser = null;
            GlobalUserLog = null;
            if (TempData["Error"] != null)
            {
                ViewBag.ErrorMessage = TempData["Error"].ToString();
                TempData.Remove("Error");
            }
            else
            {
                ViewBag.ErrorMessage = "";
            }
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        [HttpPost]
        public ActionResult Login(string UName, string Pwd, string CompanyId)
        {
            ViewBag.error = "";
            CompanyId = "1";
            SmartXtract.iRozADService.ServiceSoapClient nts = new SmartXtract.iRozADService.ServiceSoapClient();
            var ntDs = nts.GetNtIDAuth(UName, Pwd);
            if (ntDs.Tables.Count > 0 && ntDs.Tables[0].Columns.Count > 1 && ntDs.Tables[0].Rows.Count > 0)
            {
                SmartXtract_User newusr = new SmartXtract_User();
                newusr.USERCODE = ntDs.Tables[0].Rows[0]["EMPNUMBER"].ToString();
                newusr.LOGINNAME = ntDs.Tables[0].Rows[0]["NTLOGIN"].ToString();
                newusr.FIRSTNAME = ntDs.Tables[0].Rows[0]["EMPFIRSTNAME"].ToString();
                newusr.LASTNAME = ntDs.Tables[0].Rows[0]["EMPLASTNAME"].ToString();
                newusr.LASTPWDCHANGE = DateTime.Now;
                newusr.VENDORID = 1;
                newusr.LOCATIONID = 1;
                newusr.CREATEDDATE = DateTime.Now;
                newusr.CREATEDBY = 1;
                newusr.RoleId = 7;
                newusr.CompanyId = 1;
                newusr.StatusId = 1;
                newusr.RECORDSTATUS = 1; 

                GlobalUser = newusr;
                GlobalUserLog = null;
                return RedirectToAction("Index", "Dashboard", new { area = "Admin" });
            }
            else
            {
                GlobalUser = null;
                GlobalUserLog = null;
                TempData["Error"] = "Invalid username or password";
                return RedirectToAction("Index");

            }

        }

        public ActionResult SignUp()
        {
            return View();
        }

        public ActionResult ForgetPassword()
        {
            return View();
        }
    }
}