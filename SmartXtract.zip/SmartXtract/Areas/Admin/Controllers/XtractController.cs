﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Xml;
using System.Xml.XPath; 
using System.Text; 
using SmartXtract.Common;

namespace SmartXtract.Areas.Admin.Controllers
{
    [RouteArea("Admin")]
    public class XtractController : Controller
    {
        // GET: Admin/Xtract
        #region Declaration 
        string logtext = string.Empty; 
        string ProjectName = string.Empty; 
         XmlDocument Domtemplate = new XmlDocument();
        Transform trnsobj = new Transform();
        public OCRProcess.Service1Client objClientOCRProcess = new OCRProcess.Service1Client();
        public Pdf2TextService.XtractionTabulaServiceClient objTabula = new Pdf2TextService.XtractionTabulaServiceClient();
        #endregion

        #region Text Xtraction
        public ActionResult TextXtract(string CategoryName)
        {
            ViewBag.CategoryName = CategoryName;
            TempData["Category"] = CategoryName;
            TempData.Keep("Category"); 
            return View();
        }
        public ActionResult CallTextXtract(string button, string templateId)
        {
            string ErrorMessage = "";
            string strFileName = "";
            TEMPLATEDATA tempdata = new TEMPLATEDATA();
            if (Request.Files.Count > 0)
            {
                for (int i = 0; i < Request.Files.Count; i++)
                {
                    HttpPostedFileBase file = Request.Files[i];
                    if (file != null)
                    {
                        byte[] imgData = new byte[file.ContentLength];
                        int result = file.InputStream.Read(imgData, 0, file.ContentLength);
                        strFileName = System.IO.Path.GetFileNameWithoutExtension(file.FileName).ToString();
                        //strFileName = file.FileName;
                        //File Extension
                        var supportedTypes = new[] { "jpg", "png", "gif", "tif", "tiff" };
                        var fileExt = Path.GetExtension(file.FileName).Substring(1);
                        if (!supportedTypes.Contains(fileExt))
                        {
                            ErrorMessage = "File Extension Is InValid - Only Upload JPG/PNG/GIF/TIF File";
                            ViewBag.ErrorMessage = ErrorMessage;
                        }
                        //now convert byte[] to Base64
                        string inputData = Encoding.UTF8.GetString(imgData);
                        Pdf2TextService.Xtraction objXtract = new Pdf2TextService.Xtraction();
                        objXtract.RequestBase64 = imgData;
                        objXtract.RequestType = Pdf2TextService.Xtraction.RequestTypeEnum.Base64;
                        if (TempData["Category"] != null)
                        {
                            objXtract.ProjectName = Convert.ToString(TempData["Category"]);
                            TempData.Keep("Category");
                            ProjectName = objXtract.ProjectName;
                        }
                        else
                            objXtract.ProjectName = "GPC";

                        objXtract.TemplateName = templateId;//"AUSTRAL DISTRIBUTING CO PL-1";
                        Pdf2TextService.Xtraction Response = objTabula.XtractData(objXtract);
                        byte[] byteResult = Response.ResponsestBase64;
                        //string strPath = @"C:\Users\solkings\AppData\Local\Temp\GPC.XML";
                        //System.IO.File.WriteAllBytes(strPath, byteResult);
                        byte[] mem_bytes = byteResult;
                        XmlDocument resDoc = new XmlDocument();
                        using (var ms = new MemoryStream(mem_bytes))
                        using (var reader = new StreamReader(ms))
                        {
                            while (!reader.EndOfStream && reader.Peek() > -1 && (char)reader.Peek() != '<')
                                reader.Read();
                            if (!reader.EndOfStream)
                                resDoc.Load(reader);
                            XmlNode oRootNode = resDoc.DocumentElement;
                            tempdata.TD_TEMPLATENAME = ProjectName;
                            tempdata.TD_CREATEDDATE = DateTime.Now;
                            tempdata.TD_RECORDSTATUS = 1;

                            tempdata.TD_INPUTIMAGE = mem_bytes;
                            List<TEMPLATECOORDIANATE> jdList = new List<TEMPLATECOORDIANATE>();
                            int row = -1, column = 0;
                            foreach (XmlNode node in resDoc.DocumentElement.ChildNodes)
                            {
                                bool isLineItem = false;
                                string AttrName = node.Name;
                                string AttrValue = node.InnerText.Replace('"', ' ');
                                if (node.HasChildNodes)
                                {
                                    if (node.ChildNodes.Count > 1 || node.ChildNodes[0].NodeType == XmlNodeType.Element)
                                    {
                                        row++;
                                        column = 0;
                                        foreach (XmlNode childNode in node.ChildNodes)
                                        {
                                            isLineItem = true;
                                            string AttrLineName = childNode.Name;
                                            string AttrLineValue = childNode.InnerText.Replace('"', ' ');
                                            TEMPLATECOORDIANATE jdLineItem = new TEMPLATECOORDIANATE();
                                            jdLineItem.TC_TEMPLATECOORDIANATENAME = (childNode.Name.StartsWith("_")) ? childNode.Name.Substring(1) : childNode.Name;
                                            jdLineItem.TC_TEMPLATECOORDINATEVALUE = AttrLineValue;
                                            jdLineItem.TC_NODETYPE = "LINEITEM";
                                            jdLineItem.TC_ROWPOSITION = row;
                                            jdLineItem.TC_COLUMNPOSITION = column++;
                                            jdLineItem.TC_RECORDSTATUS = 1;
                                            jdList.Add(jdLineItem);
                                            tempdata.TEMPLATECOORDIANATE = jdList;
                                        }
                                    }
                                }
                                if (!isLineItem)
                                {
                                    TEMPLATECOORDIANATE jd = new TEMPLATECOORDIANATE();
                                    jd.TC_TEMPLATECOORDIANATENAME = (node.Name.StartsWith("_")) ? node.Name.Substring(1) : node.Name;
                                    jd.TC_TEMPLATECOORDINATEVALUE = AttrValue;
                                    jd.TC_NODETYPE = "HEADER";
                                    jd.TC_ROWPOSITION = 0;
                                    jd.TC_COLUMNPOSITION = 0;
                                    jd.TC_RECORDSTATUS = 1;
                                    jdList.Add(jd);
                                    tempdata.TEMPLATECOORDIANATE = jdList;

                                }
                            }
                        }
                    }
                }
            }
            return PartialView("SearchPdfTextDetails", tempdata);
        }
        #endregion

        [ChildActionOnly]
        public ActionResult SearchPdfTextDetails(string filename)
        {
            return PartialView(); 
        }


        #region Image Xtraction
        public ActionResult ImageXtract(string CategoryName)
        {
            ViewBag.CategoryName = CategoryName;
            TempData["Category"] = CategoryName;
            TempData.Keep("Category");
            return View();
        }

        public JsonResult CallImageXtract(string button,string pagename)
        {
            try
            {
                string ErrorMessage = "";
                string strFileName = "";
                string[] ImageResult = { };
                string TemplateName = string.Empty;
                string strTemplatePath = string.Empty;

                if (Request.Files.Count > 0)
                {
                    for (int i = 0; i < Request.Files.Count; i++)
                    {
                        HttpPostedFileBase file = Request.Files[i];
                        if (file != null)
                        {
                            byte[] imgData = new byte[file.ContentLength];
                            int result = file.InputStream.Read(imgData, 0, file.ContentLength);
                            strFileName = System.IO.Path.GetFileNameWithoutExtension(file.FileName).ToString();
                            //strFileName = file.FileName;
                            //File Extension
                            var supportedTypes = new[] { "jpg", "png", "gif", "tif", "tiff", "pdf" };
                            var fileExt = System.IO.Path.GetExtension(file.FileName).Substring(1);
                            if (!supportedTypes.Contains(fileExt))
                            {
                                ErrorMessage = "File Extension Is InValid - Only Upload JPG/PNG/GIF/TIF File";
                                ViewBag.ErrorMessage = ErrorMessage;
                            }
                            //now convert byte[] to Base64
                            string inpBase64Data = Convert.ToBase64String(imgData);
                            OCRProcess.Response resp = new OCRProcess.Response();
                            if (TempData["Category"] != null)
                            {
                                TemplateName = Convert.ToString(TempData["Category"]);
                                TempData.Keep("Category"); 
                            }
                            else
                                TemplateName = "SIG";
                            resp = OCRService(inpBase64Data, strFileName, fileExt, TemplateName);  //Calling We service
                            string[] resultXML = resp.Document;
                            string[] resultTiff = resp.TiffFile;
                            try
                            {
                                //if(pagename.ToUpper() != "TEXTPDFXTRACT")
                                if (TemplateName.ToLower().Contains("appraisal"))
                                {
                                    if (resultXML != null)
                                        ReadXML(resultXML, 0, pagename, TemplateName);
                                }
                                else
                                {
                                    if (resultXML != null)
                                    {
                                        SaveImage(resultTiff, Path.GetFileNameWithoutExtension(strFileName)); // To save image in local folder

                                        for (int k = 0; k < resultXML.Length; k++)
                                        {
                                            ReadXML(resultXML, k, pagename, TemplateName);
                                        }
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                logtext = ex.Message.ToString();
                                trnsobj.WriteStatusLog(logtext + "|" + "Error in LoadXML function");
                            }
                        }
                    }
                }
                ViewBag.Data = logtext;
            }
            catch (Exception e)
            {
                logtext = e.Message.ToString();
                trnsobj.WriteStatusLog(logtext + "|" + "Error in LoadXML function");
            }
            return Json(Domtemplate.OuterXml, JsonRequestBehavior.AllowGet);
        }
        private void ReadXML(string[] resultXML,int i,string pagename,string TemplateName)
        {
            string ErrorMessage = "";
            string[] ImageResult = { };
            string strTemplatePath = string.Empty;
            try
            {
                if (resultXML[i].ToString() != "")
                {
                    byte[] mem_bytes = Convert.FromBase64String(resultXML[i]);
                    XmlDocument resDoc = new XmlDocument();
                    using (var ms = new MemoryStream(mem_bytes))
                    using (var reader = new StreamReader(ms))
                    {
                        while (!reader.EndOfStream && reader.Peek() > -1 && (char)reader.Peek() != '<')
                            reader.Read();
                        if (!reader.EndOfStream)
                            resDoc.Load(reader);
                        //Instantiate an XmlNamespaceManager object. 
                        XmlNamespaceManager nsMgr = new XmlNamespaceManager(resDoc.NameTable);
                        XPathNavigator nav = resDoc.CreateNavigator();
                        XmlNamespaceManager nsmgr = new XmlNamespaceManager(nav.NameTable);
                        // Retrieve the namespaces into a Generic dictionary with string keys.
                        nsMgr.AddNamespace("form", "http://www.abbyy.com/FlexiCapture/Schemas/Export/FormData.xsd");
                        nsMgr.AddNamespace("xsi", "http://www.w3.org/2001/XMLSchema-instance");
                        nsMgr.AddNamespace("addData", "http://www.abbyy.com/FlexiCapture/Schemas/Export/AdditionalFormData.xsd");
                        XmlNode oRootNode = resDoc.DocumentElement;
                        //Suganya for generic code 20th Dec 2018
                        XmlNode nlNode = resDoc.DocumentElement.FirstChild;
                        if (TemplateName != "")
                        {
                            strTemplatePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, TemplateName + ".html");
                            Domtemplate.Load(strTemplatePath);
                            int cntIteration = 1;
                            foreach (XmlNode node in nlNode.ChildNodes)
                            {
                                string AttrName = node.Name;
                                string AttrValue = node.InnerText;

                                NodeIteration(node, TemplateName, nsMgr, pagename, cntIteration);
                                cntIteration++;
                            }
                        }
                        else
                        {
                            ErrorMessage = "Template is not given";
                            ViewBag.ErrorMessage = ErrorMessage;
                        }
                    }
                }
            }
            catch(Exception ex)
            {

            }
        }
        #endregion

        #region TextPdf Xtraction
        public ActionResult TextPdfXtract(string CategoryName)
        {
            ViewBag.CategoryName = CategoryName;
            TempData["Category"] = CategoryName;
            TempData.Keep("Category");
            //ViewBag.TemplateId = new SelectList(templatecomp.GetTemplateDropdown(), "TemplateID", "VendorName");
            return View();
        }
         
        #endregion

        #region General function
        public OCRProcess.Response OCRService(string inpBase64Data,string strFileName, string fileExt,string TemplateName)
        {
            OCRProcess.Request req = new OCRProcess.Request();
            OCRProcess.Response resp = new OCRProcess.Response();
            try
            {
                if (TempData["Category"] != null)
                {
                    req.ProjectName = Convert.ToString(TempData["Category"]);
                    TempData.Keep("Category");
                    TemplateName = req.ProjectName;
                }
                else
                    req.ProjectName = "SIG"; // ARGO,ZITTER Argo
                req.Classification = OCRProcess.enumClassification.Bank_Documents; //ARGO--> BANK DOCUMENT
                req.DocumentName = strFileName; //Any Name
                req.DocType = OCRProcess.DocType.Forms; //FORM
                req.DocumentExtension = fileExt.ToUpper().ToString(); //TIFF,JPG ETC
                req.InputDocument = inpBase64Data;//BASE64 IMAGE
                try
                { 

                    resp = objClientOCRProcess.DoExtractUsingBase64(req, true);
                }
                catch (Exception ex)
                {
                    resp = objClientOCRProcess.DoExtractUsingBase64(req, true);
                }
            }
            catch(Exception ex)
            {
               
            }
            return resp;
        }
        public String GetAttribute(XmlNode SelectNode, String AttrName)
        {
            String sReturn = "";
            try
            {
                if (SelectNode != null)
                {
                    if (SelectNode.Attributes.GetNamedItem(AttrName) != null)
                    {
                        return SelectNode.Attributes.GetNamedItem(AttrName).Value;
                    }
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            return sReturn;
        }
        public void SaveImage(string[] ImageResult, string strFileName)
        {
            int count = 1;
            foreach (var image in ImageResult)
            {
                string strPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Tif");
                if (!Directory.Exists(strPath))
                    Directory.CreateDirectory(strPath);
                string filePath = Path.Combine(strPath, strFileName + count + ".tif");
                System.IO.File.WriteAllBytes(filePath, Convert.FromBase64String(image));
                count++;
            }
        }
        public void NodeIteration(XmlNode node, string strTemplatename,XmlNamespaceManager nsMgrs,string pageName,int cntIteration )
        {
            try
            {
               
                XmlNode SelectionLineNode = null;
                int PageIndex = 0;
                long Top = 0;
                long Left = 0;
                long Right = 0;
                long Bottom = 0;
                string NodeLineval = GetAttribute(node, "addData:BlockRef");
                if (NodeLineval != "")
                { 
                    SelectionLineNode = node.SelectSingleNode(@"//addData:Blocks[@Id=""" + NodeLineval + @"""]//addData:Rect", nsMgrs);
                    XmlNode SelectionIndex = node.SelectSingleNode(@"//addData:Blocks[@Id=""" + NodeLineval + @"""]", nsMgrs);
                    if (SelectionIndex != null)
                    {
                        PageIndex = Convert.ToInt32(SelectionIndex.FirstChild.Attributes.GetNamedItem("PageIndex").Value);
                    }
                }
                //Find Co-Ordinates
                if (SelectionLineNode != null)
                {

                    Top = Convert.ToInt64(GetAttribute(SelectionLineNode, "Top"));
                    Left = Convert.ToInt64(GetAttribute(SelectionLineNode, "Left"));
                    Right = Convert.ToInt64(GetAttribute(SelectionLineNode, "Right"));
                    Bottom = Convert.ToInt64(GetAttribute(SelectionLineNode, "Bottom"));
                }

                //if(pageName.ToUpper() != "TEXTPDFXTRACT")
                //    BindNodewithoutCoordinateDOM(node);
                if (strTemplatename.ToUpper().Contains("LOAN") ==true)
                    BindNodewithDOM(node, Top, Left, Right, Bottom, strTemplatename + Convert.ToString(PageIndex) + ".tif", nsMgrs, cntIteration);
                else if (strTemplatename.ToUpper().Contains("APPRAISAL") == true || strTemplatename.ToUpper().Contains("GPC") == true)
                    BindNodewithoutCoordinateDOM(node, cntIteration);
               
            }
            catch (Exception ex)
            {

            }
        }
        public void BindNodewithDOM(XmlNode Node, long Top, long Left, long Right, long Bottom, string ImageName, XmlNamespaceManager nsmgr, int NodeIteration)
        {
            if (Node != null)
            {
                if (Node.NodeType == XmlNodeType.Element)
                {
                    if (Node.HasChildNodes)
                    {
                        int childcount = 0;
                        foreach (XmlNode ChildNode in Node.ChildNodes)
                        {
                            int PageIndex = 0;
                            long ChildTop = 0;
                            long ChildLeft = 0;
                            long ChildRight = 0;
                            long ChildBottom = 0;
                            XmlNode SelectionLineNode = null;
                            string NodeLineval = GetAttribute(ChildNode, "addData:BlockRef");
                            if (NodeLineval != "")
                            {
                                //XmlNamespaceManager nsMgr = new XmlNamespaceManager();
                                SelectionLineNode = ChildNode.SelectSingleNode(@"//addData:Blocks[@Id=""" + NodeLineval + @"""]//addData:Rect", nsmgr);
                                XmlNode SelectionIndex = ChildNode.SelectSingleNode(@"//addData:Blocks[@Id=""" + NodeLineval + @"""]", nsmgr);
                                if (SelectionIndex != null)
                                {
                                    PageIndex = Convert.ToInt32(SelectionIndex.FirstChild.Attributes.GetNamedItem("PageIndex").Value);
                                }
                            }
                            //Find Co-Ordinates
                            if (SelectionLineNode != null)
                            {

                                ChildTop = Convert.ToInt64(GetAttribute(SelectionLineNode, "Top"));
                                ChildLeft = Convert.ToInt64(GetAttribute(SelectionLineNode, "Left"));
                                ChildRight = Convert.ToInt64(GetAttribute(SelectionLineNode, "Right"));
                                ChildBottom = Convert.ToInt64(GetAttribute(SelectionLineNode, "Bottom"));
                            }
                            BindNodewithDOM(ChildNode, ChildLeft, ChildTop, ChildRight, ChildBottom, ImageName, nsmgr, NodeIteration + childcount);
                            childcount++;
                        }
                        XmlNode FindNode = Domtemplate.SelectSingleNode(@"//node()[@id=""" + Node.Name + @"""]");
                        var FindTextNode = Domtemplate.SelectSingleNode(@"//node()[@id=""txt" + Node.Name + @"""]");
                        if (FindNode != null)
                        {
                            string TypeAttribute = "";
                            if (FindNode.Attributes.GetNamedItem("Type") != null)
                            {
                                TypeAttribute = FindNode.Attributes.GetNamedItem("Type").Value;
                            }
                            if (TypeAttribute == "")
                            {
                                FindNode.InnerText = Node.InnerText;
                                if (FindTextNode != null)
                                {
                                    FindTextNode.Attributes["value"].Value = Node.InnerText;
                                    FindTextNode.Attributes["onclick"].Value = "SetImageCropping(" + Left + "," + Top + "," + Right + "," + Bottom + ",'" + ImageName + "');";
                                    string id = Node.Name;
                                    FindTextNode.Attributes["onchange"].Value = "SetText('#txt" + id + "','#" + id + "');";
                                }
                            }
                            else
                            {
                               
                                XmlNode tr = Domtemplate.CreateElement("tr");
                                int i = 0;
                                foreach (XmlNode LineChildNode in Node.ChildNodes)
                                {
                                    XmlNode td = Domtemplate.CreateElement("td");
                                    //Create an input type dynamically.
                                    var element = Domtemplate.CreateElement("input");
                                    //Assign different attributes to the element.
                                    element.SetAttribute("type", "text");
                                    element.SetAttribute("value", LineChildNode.InnerText);
                                    string id = LineChildNode.Name.Replace(" ", "") + NodeIteration + i;
                                    element.SetAttribute("id", "txt" + id);
                                    element.SetAttribute("onclick", "SetImageCropping('" + Left + "','" + Top + "','" + Right + "','" + Bottom + "','" + ImageName + "');");
                                    element.SetAttribute("onchange", "SetText('#txt" + id + "','#lbl" + id + "');");
                                    element.SetAttribute("class", "autohidetextboxvisible col form-control");
                                    element.SetAttribute("style", "font-weight: bold;");
                                    var lbl = Domtemplate.CreateElement("label");
                                    lbl.SetAttribute("id", "lbl" + id);
                                    lbl.SetAttribute("style", "display:none;");
                                    lbl.InnerText = LineChildNode.InnerText;
                                    td.AppendChild(element);
                                    td.AppendChild(lbl);
                                    tr.AppendChild(td);
                                    i++;
                                }
                                if (tr.HasChildNodes)
                                {
                                    FindNode.AppendChild(tr);
                                    if (FindTextNode != null)
                                        FindTextNode.AppendChild(tr);
                                }
                            }
                        }
                        else
                        {

                        }
                    }
                    else
                    {

                    }
                }
            }
        }
        public void BindNodewithoutCoordinateDOM(XmlNode Node, int NodeIteration)
        {
            if (Node != null)
            {
                if (Node.NodeType == XmlNodeType.Element)
                {
                    if (Node.HasChildNodes)
                    {
                        foreach (XmlNode ChildNode in Node.ChildNodes)
                        {
                            BindNodewithoutCoordinateDOM(ChildNode, NodeIteration);
                        }

                        XmlNode FindNode = Domtemplate.SelectSingleNode(@"//node()[@id=""" + Node.Name + @"""]");
                        XmlNode FindTextNode = Domtemplate.SelectSingleNode(@"//node()[@id=""txt" + Node.Name + @"""]");

                        if (FindNode != null)
                        {
                            string TypeAttribute = "";
                            if (FindNode.Attributes.GetNamedItem("Type") != null)
                            {
                                TypeAttribute = FindNode.Attributes.GetNamedItem("Type").Value;
                            }
                            if (TypeAttribute == "")
                            {
                                FindNode.InnerText = Node.InnerText;
                                if (FindTextNode != null)
                                    FindTextNode.Attributes["value"].Value = Node.InnerText;
                            }
                            else
                            {
                                XmlNode tr = Domtemplate.CreateElement("tr");
                                int i = 0;
                                foreach (XmlNode LineChildNode in Node.ChildNodes)
                                {
                                    XmlNode td = Domtemplate.CreateElement("td");
                                    //Create an input type dynamically.
                                    var element = Domtemplate.CreateElement("input");
                                    //Assign different attributes to the element.
                                    element.SetAttribute("type", "text");
                                    element.SetAttribute("value", LineChildNode.InnerText);
                                    string id = LineChildNode.Name.Replace(" ", "") + NodeIteration + i;
                                    element.SetAttribute("id", "txt" + id);
                                    element.SetAttribute("onclick", "SearchPDF(this.id)"); 
                                    element.SetAttribute("class", "autohidetextboxvisible col form-control");
                                    element.SetAttribute("style", "font-weight: bold;");
                                    var lbl = Domtemplate.CreateElement("label");
                                    lbl.SetAttribute("id", "lbl" + id);
                                    lbl.SetAttribute("style", "display:none;");
                                    lbl.InnerText = LineChildNode.InnerText;
                                    td.AppendChild(element);
                                    td.AppendChild(lbl);
                                    tr.AppendChild(td);
                                    i++;
                                }
                                if (tr.HasChildNodes)
                                {
                                    FindNode.AppendChild(tr);
                                    if (FindTextNode != null)
                                        FindTextNode.AppendChild(tr);
                                }


                                //XmlNode tr = Domtemplate.CreateElement("tr");
                                //foreach (XmlNode LineChildNode in Node.ChildNodes)
                                //{
                                //    XmlNode td = Domtemplate.CreateElement("td");
                                //    td.InnerText = LineChildNode.InnerText;
                                //    tr.AppendChild(td);

                                //}
                                //if (tr.HasChildNodes)
                                //{
                                //    FindNode.AppendChild(tr);
                                //}
                            }
                        }
                        else
                        {

                        }
                    }
                }
            }
        }
        #endregion


    }
}