﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Web;
using System.Web.Mvc;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Xml;
using System.Xml.Serialization;
using System.Xml.XPath;
using SmartXtract.Common;

namespace SmartXtract.Areas.Admin.Controllers
{
    [RouteArea("Admin")]
    public class DashboardController : Controller
    {

        #region Declaration

        XmlDocument LoanTemplate = new XmlDocument();
        XmlDocument PayStubTemplate = new XmlDocument();

        public FineReaderService.Service1Client objClientFineReaderService = new FineReaderService.Service1Client();
        public OCRProcess.Service1Client objClientOCRProcess = new OCRProcess.Service1Client();
        public Pdf2TextService.XtractionTabulaServiceClient objTabula = new Pdf2TextService.XtractionTabulaServiceClient();

        private String[] ArryOFImageFile;

        private int PagePos = 0;
        private string ViewMode = "";
        private string ProjectName = string.Empty;
        int TabIndex = 0;
        private string logtext = "";
        Transform trnsobj = new Transform();

        //Translatorservice objTranslation = new Translatorservice();
        String Transflag = string.Empty;
        Table tblLineItem = null;
        public class ImageInfo
        {
            public int Left = 0;
            public int Top = 0;
            public int Right = 10;
            public int Bottom = 10;
            public int ctrlWidth = 10;

            public String SuspiciousSymbols = "";
            public int RowIndex = 0;
            public String OrginalText = "";
            public string OutputXmlPath = string.Empty;

        }

        XmlDocument doc = new XmlDocument();
        private string OutputXmlPath;
        private string OutputXmlFileNamewithFullPath;
        public string xmlfilename = string.Empty;
        private string strBasePath;
        private string strCleanupPath;
        private string strOCRProcessPath;
        private string strXMLoutputPath;
        private string ColorFlag = "false";
        string Template = string.Empty;
         
        XmlDocument oOcrDoc = new XmlDocument();
        XmlNamespaceManager xmlNameSpace;
        XmlDocument xmlDoc = new XmlDocument();
        float ConfidentScore = 0;
        float overallConf = 0;
        float NodeTextCount = 0;
        float NodeCount = 0;
        string result = string.Empty;
         
        //public Transform transform = new Transform();
        public HttpPostedFileBase ImgFileName { get; set; }

        #endregion
        string strLogPath = string.Empty;
        string strLogFile = string.Empty;

        // GET: Admin/Dashboard
        public ActionResult Index()
        {
            return View();
        }

        #region Paystub
         
        public ActionResult CreatePayStub(string CategoryName)
        {
            ViewBag.CategoryName = CategoryName;
            TempData["Category"] = CategoryName;
            TempData.Keep("Category"); 

            TEMPLATEDATA processData = new TEMPLATEDATA();
            ViewBag.ClientId = new SelectList(GetClientDropDown(), "Value", "Text");
            ViewBag.TemplateId = new SelectList(GetTemplateDropDown(), "Value", "Text");
            ViewBag.CategoryId = new SelectList(GetCategoryDropDown(), "Value", "Text");
            if (processData == null)
            {
                return HttpNotFound();
            }
            return View(processData);
        }

        public JsonResult PayStubExtraction(string button)
        {
            try
            {
                decimal filesize = 0;
                string ErrorMessage = "";
                string strFileName = "";
                string[] ImageResult = { };
                string TemplateName = string.Empty;
                string strTemplatePath = string.Empty;

                TEMPLATEDATA tempdata = new TEMPLATEDATA();
                TEMPLATEDATA templistdata = new TEMPLATEDATA();
                if (button == "")
                {
                    if (Request.Files.Count > 0)
                    {
                        for (int i = 0; i < Request.Files.Count; i++)
                        {
                            HttpPostedFileBase file = Request.Files[i];
                            if (file != null)
                            {
                                byte[] imgData = new byte[file.ContentLength];
                                int result = file.InputStream.Read(imgData, 0, file.ContentLength);
                                strFileName = System.IO.Path.GetFileNameWithoutExtension(file.FileName).ToString();
                                //strFileName = file.FileName;
                                //File Extension
                                var supportedTypes = new[] { "jpg", "png", "gif", "tif", "tiff", "pdf" };
                                var fileExt = System.IO.Path.GetExtension(file.FileName).Substring(1);
                                if (!supportedTypes.Contains(fileExt))
                                {
                                    ErrorMessage = "File Extension Is InValid - Only Upload JPG/PNG/GIF/TIF File";
                                    ViewBag.ErrorMessage = ErrorMessage;
                                }
                                else
                                {
                                    ErrorMessage = "File Is Successfully Uploaded";
                                    ViewBag.ErrorMessage = ErrorMessage;
                                }
                                //now convert byte[] to Base64
                                string inpBase64Data = Convert.ToBase64String(imgData);
                                OCRProcess.Request req = new OCRProcess.Request();
                                OCRProcess.Response resp = new OCRProcess.Response();
                                if (TempData["Category"] != null)
                                {
                                    req.ProjectName = Convert.ToString(TempData["Category"]);
                                    TempData.Keep("Category");
                                    TemplateName = req.ProjectName;
                                }
                                else
                                    req.ProjectName = "SIG"; // ARGO,ZITTER Argo
                                req.Classification = OCRProcess.enumClassification.Bank_Documents; //ARGO--> BANK DOCUMENT
                                req.DocumentName = OCRProcess.enumClassification.Bank_Documents.ToString(); //Any Name
                                req.DocType = OCRProcess.DocType.Forms; //FORM
                                req.DocumentExtension = fileExt.ToUpper().ToString(); //TIFF,JPG ETC
                                req.InputDocument = inpBase64Data;//BASE64 IMAGE
                                try
                                {
                                    resp = objClientOCRProcess.DoExtractUsingBase64(req, true);
                                }
                                catch (Exception ex)
                                {
                                    resp = objClientOCRProcess.DoExtractUsingBase64(req, true);
                                }
                                string[] resultXML = resp.Document;
                                string[] resultTiff = resp.TiffFile;
                                ImageResult = resultTiff;
                                int Count = 1;
                                foreach (var image in ImageResult)
                                {
                                    string strPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Tif");
                                    if (!Directory.Exists(strPath))
                                        Directory.CreateDirectory(strPath);
                                    string filePath = Path.Combine(strPath, TemplateName + Count + ".tif");
                                    System.IO.File.WriteAllBytes(filePath, Convert.FromBase64String(image));
                                    Count++;
                                }
                                try
                                {
                                    if (resultXML[0].ToString() != "")
                                    {
                                        byte[] mem_bytes = Convert.FromBase64String(resultXML[0]);
                                        XmlDocument resDoc = new XmlDocument();
                                        using (var ms = new MemoryStream(mem_bytes))
                                        using (var reader = new StreamReader(ms))
                                        {
                                            while (!reader.EndOfStream && reader.Peek() > -1 && (char)reader.Peek() != '<')
                                                reader.Read();
                                            if (!reader.EndOfStream)
                                                resDoc.Load(reader);
                                            //Instantiate an XmlNamespaceManager object. 
                                            XmlNamespaceManager nsMgr = new XmlNamespaceManager(resDoc.NameTable);
                                            XPathNavigator nav = resDoc.CreateNavigator();
                                            XmlNamespaceManager nsmgr = new XmlNamespaceManager(nav.NameTable);
                                            // Retrieve the namespaces into a Generic dictionary with string keys.
                                            nsMgr.AddNamespace("form", "http://www.abbyy.com/FlexiCapture/Schemas/Export/FormData.xsd");
                                            nsMgr.AddNamespace("xsi", "http://www.w3.org/2001/XMLSchema-instance");
                                            nsMgr.AddNamespace("addData", "http://www.abbyy.com/FlexiCapture/Schemas/Export/AdditionalFormData.xsd");
                                            XmlNode oRootNode = resDoc.DocumentElement;
                                            tempdata.TD_TEMPLATENAME = ProjectName;
                                            tempdata.TD_CREATEDDATE = DateTime.Now;
                                            tempdata.TD_RECORDSTATUS = 1;
                                            tempdata.TD_INPUTIMAGE = mem_bytes;
                                            List<TEMPLATECOORDIANATE> jdList = new List<TEMPLATECOORDIANATE>();

                                            XmlNode nlNode = resDoc.DocumentElement.FirstChild;
                                            if (TemplateName.ToUpper().Contains("PAYSTUB"))
                                            {
                                                if (TemplateName.ToUpper().Contains("PAYSTUB") == true)
                                                    strTemplatePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "PaystubTemplate.HTML");

                                                PayStubTemplate.Load(strTemplatePath);

                                                var format = new NumberFormatInfo();
                                                format.NegativeSign = "-";
                                                format.NumberNegativePattern = 1;
                                                format.NumberDecimalSeparator = ".";
                                                format.NumberGroupSeparator = ",";

                                                ////Get Sum of _TaxPay
                                                XmlNodeList taxPay = resDoc.SelectNodes("//_TaxPay");
                                                decimal taxPaySum = 0;
                                                foreach (XmlNode tp in taxPay)
                                                {
                                                    taxPaySum += decimal.Parse(taxPaySum.ToString(), NumberStyles.Number) + decimal.Parse(Common.Common.Parse(tp.InnerText.ToString()), NumberStyles.Number);
                                                    //taxPaySum = Double.TryParse(taxPaySum, NumberStyles.AllowDecimalPoint | NumberStyles.AllowLeadingSign, format, out taxPaySum) + Double.TryParse(tp.InnerText, NumberStyles.AllowDecimalPoint | NumberStyles.AllowLeadingSign, format, out taxPaySum);
                                                }

                                                ////Get Sum of _TaxPayYTD
                                                XmlNodeList taxPayYTD = resDoc.SelectNodes("//_TaxPayYTD");
                                                decimal taxPaySumYTD = 0;
                                                foreach (XmlNode tpytd in taxPayYTD)
                                                {
                                                    taxPaySumYTD += decimal.Parse(taxPaySumYTD.ToString(), NumberStyles.Number) + decimal.Parse(Common.Common.Parse(tpytd.InnerText.ToString()), NumberStyles.Number);
                                                }

                                                ////Get Sum of _NetPay
                                                XmlNodeList netPay = resDoc.SelectNodes("//_DeductionPay");
                                                decimal netPaySum = 0;
                                                foreach (XmlNode tp in netPay)
                                                {
                                                    netPaySum += decimal.Parse(netPaySum.ToString(), NumberStyles.Number) + decimal.Parse(Common.Common.Parse(tp.InnerText.ToString()), NumberStyles.Number);
                                                    //taxPaySum = Double.TryParse(taxPaySum, NumberStyles.AllowDecimalPoint | NumberStyles.AllowLeadingSign, format, out taxPaySum) + Double.TryParse(tp.InnerText, NumberStyles.AllowDecimalPoint | NumberStyles.AllowLeadingSign, format, out taxPaySum);
                                                }

                                                ////Get Sum of _NetPayYTD
                                                XmlNodeList netPayYTD = resDoc.SelectNodes("//_DeductionPayYTD");
                                                decimal netPaySumYTD = 0;
                                                foreach (XmlNode tpytd in netPayYTD)
                                                {
                                                    netPaySumYTD += decimal.Parse(netPaySumYTD.ToString(), NumberStyles.Number) + decimal.Parse(Common.Common.Parse(tpytd.InnerText.ToString()), NumberStyles.Number);
                                                }

                                                ////Get Sum of _TaxPay
                                                XmlNodeList grossPay = resDoc.SelectNodes("//_GrossPay");
                                                decimal grossPaySum = 0;
                                                foreach (XmlNode tp in grossPay)
                                                {
                                                    grossPaySum += decimal.Parse(grossPaySum.ToString(), NumberStyles.Number) + decimal.Parse(Common.Common.Parse(tp.InnerText.ToString()), NumberStyles.Number);
                                                    //taxPaySum = Double.TryParse(taxPaySum, NumberStyles.AllowDecimalPoint | NumberStyles.AllowLeadingSign, format, out taxPaySum) + Double.TryParse(tp.InnerText, NumberStyles.AllowDecimalPoint | NumberStyles.AllowLeadingSign, format, out taxPaySum);
                                                }

                                                ////Get Sum of _GrossPayYTD
                                                XmlNodeList grossPayYTD = resDoc.SelectNodes("//_GrossPayYTD");
                                                decimal grossPaySumYTD = 0;
                                                foreach (XmlNode tpytd in grossPayYTD)
                                                {
                                                    grossPaySumYTD += decimal.Parse(grossPaySumYTD.ToString(), NumberStyles.Number) + decimal.Parse(Common.Common.Parse(tpytd.InnerText.ToString()), NumberStyles.Number);
                                                }

                                                string[] SumArray = { "_TaxPay", "_TaxPayYTD", "_DeductionPay", "_DeductionPayYTD", "_GrossPay", "GrossPayYTD" };

                                                for (int k = 0; k < SumArray.Length; k++)
                                                {
                                                    foreach (XmlNode nodes in nlNode.ChildNodes)
                                                    {
                                                        if (nodes.Name == SumArray[k])
                                                        {

                                                            XmlNode FindNodes = PayStubTemplate.SelectSingleNode(@"//node()[@id=""" + SumArray[k].ToString() + @"""]");
                                                            XmlNode FindTextNodes = PayStubTemplate.SelectSingleNode(@"//node()[@id=""txt" + SumArray[k].ToString() + @"""]");

                                                            if (nodes.Name == "_TaxPay")
                                                            {
                                                                FindNodes.InnerText = taxPaySum.ToString();
                                                                if (FindTextNodes != null)
                                                                    FindTextNodes.Attributes["value"].Value = taxPaySum.ToString();
                                                            }
                                                            else if (nodes.Name == "_TaxPayYTD")
                                                            {
                                                                FindNodes.InnerText = taxPaySumYTD.ToString();
                                                                if (FindTextNodes != null)
                                                                    FindTextNodes.Attributes["value"].Value = taxPaySumYTD.ToString();
                                                            }
                                                            if (nodes.Name == "_DeductionPay")
                                                            {
                                                                FindNodes.InnerText = netPaySum.ToString();
                                                                if (FindTextNodes != null)
                                                                    FindTextNodes.Attributes["value"].Value = netPaySum.ToString();
                                                            }
                                                            if (nodes.Name == "_DeductionPayYTD")
                                                            {
                                                                FindNodes.InnerText = netPaySumYTD.ToString();
                                                                if (FindTextNodes != null)
                                                                    FindTextNodes.Attributes["value"].Value = netPaySumYTD.ToString();
                                                            }
                                                            if (nodes.Name == "_GrossPay")
                                                            {
                                                                FindNodes.InnerText = grossPaySum.ToString();
                                                                if (FindTextNodes != null)
                                                                    FindTextNodes.Attributes["value"].Value = grossPaySum.ToString();
                                                            }
                                                            if (nodes.Name == "_GrossPayYTD")
                                                            {
                                                                FindNodes.InnerText = grossPaySumYTD.ToString();
                                                                if (FindTextNodes != null)
                                                                    FindTextNodes.Attributes["value"].Value = grossPaySumYTD.ToString();
                                                            }

                                                        }

                                                    }
                                                }

                                                int NodeIteration = 0;
                                                foreach (XmlNode node in nlNode.ChildNodes)
                                                {

                                                    XmlNode SelectionLineNode = null;
                                                    int PageIndex = 0;
                                                    long Top = 0;
                                                    long Left = 0;
                                                    long Right = 0;
                                                    long Bottom = 0;
                                                    string NodeLineval = GetAttribute(node, "addData:BlockRef");
                                                    if (NodeLineval != "")
                                                    {
                                                        SelectionLineNode = node.SelectSingleNode(@"//addData:Blocks[@Id=""" + NodeLineval + @"""]//addData:Rect", nsMgr);
                                                        XmlNode SelectionIndex = node.SelectSingleNode(@"//addData:Blocks[@Id=""" + NodeLineval + @"""]", nsMgr);
                                                        if (SelectionIndex != null)
                                                        {
                                                            PageIndex = Convert.ToInt32(SelectionIndex.FirstChild.Attributes.GetNamedItem("PageIndex").Value);
                                                        }
                                                    }
                                                    //Find Co-Ordinates
                                                    if (SelectionLineNode != null)
                                                    {

                                                        Top = Convert.ToInt64(GetAttribute(SelectionLineNode, "Top"));
                                                        Left = Convert.ToInt64(GetAttribute(SelectionLineNode, "Left"));
                                                        Right = Convert.ToInt64(GetAttribute(SelectionLineNode, "Right"));
                                                        Bottom = Convert.ToInt64(GetAttribute(SelectionLineNode, "Bottom"));
                                                    }
                                                    //BindNodewithDOM(node);
                                                    BindNodewithDOM(node, Top, Left, Right, Bottom, TemplateName + Convert.ToString(PageIndex) + ".tif", nsMgr, NodeIteration);
                                                    NodeIteration++;
                                                }
                                            }
                                            else
                                            {
                                                ErrorMessage = "Template is not given";
                                                ViewBag.ErrorMessage = ErrorMessage;
                                            }
                                        }
                                    }

                                }
                                catch (Exception ex)
                                {
                                    logtext = ex.Message.ToString();
                                    trnsobj.WriteStatusLog(logtext + "|" + "Error in LoadXML function");
                                }
                            }
                        }
                    }
                }
                else
                {
                    var filnam = button.ToString();

                    var paths = Server.MapPath("~/Sample");
                    var fullpath = Path.Combine(paths, filnam);
                    string fileExt = Path.GetExtension(fullpath);

                    string pathss = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Sample") + "\\" + filnam;
                    byte[] imgData = ImageToBinary(pathss);

                    //now convert byte[] to Base64
                    string inpBase64Data = Convert.ToBase64String(imgData);
                    OCRProcess.Request req = new OCRProcess.Request();
                    OCRProcess.Response resp = new OCRProcess.Response();
                    if (TempData["Category"] != null)
                    {
                        req.ProjectName = Convert.ToString(TempData["Category"]);
                        TempData.Keep("Category");
                        TemplateName = req.ProjectName;
                    }
                    else
                        req.ProjectName = "SIG"; // ARGO,ZITTER Argo
                    req.Classification = OCRProcess.enumClassification.Bank_Documents; //ARGO--> BANK DOCUMENT
                    req.DocumentName = OCRProcess.enumClassification.Bank_Documents.ToString(); //Any Name
                    req.DocType = OCRProcess.DocType.Forms; //FORM
                    req.DocumentExtension = fileExt.ToUpper().ToString(); //TIFF,JPG ETC
                    req.InputDocument = inpBase64Data;//BASE64 IMAGE

                    try
                    {
                        resp = objClientOCRProcess.DoExtractUsingBase64(req, true);
                    }
                    catch (Exception ex)
                    {
                        resp = objClientOCRProcess.DoExtractUsingBase64(req, true);
                    }
                    string[] resultXML = resp.Document;
                    string[] resultTiff = resp.TiffFile;
                    ImageResult = resultTiff;
                    int Count = 1;

                    try
                    {
                        if (resultXML[0].ToString() != "")
                        {
                            byte[] mem_bytes = Convert.FromBase64String(resultXML[0]);
                            XmlDocument resDoc = new XmlDocument();
                            using (var ms = new MemoryStream(mem_bytes))
                            using (var reader = new StreamReader(ms))
                            {
                                while (!reader.EndOfStream && reader.Peek() > -1 && (char)reader.Peek() != '<')
                                    reader.Read();
                                if (!reader.EndOfStream)
                                    resDoc.Load(reader);
                                //Instantiate an XmlNamespaceManager object. 
                                XmlNamespaceManager nsMgr = new XmlNamespaceManager(resDoc.NameTable);
                                XPathNavigator nav = resDoc.CreateNavigator();
                                XmlNamespaceManager nsmgr = new XmlNamespaceManager(nav.NameTable);
                                // Retrieve the namespaces into a Generic dictionary with string keys.
                                nsMgr.AddNamespace("form", "http://www.abbyy.com/FlexiCapture/Schemas/Export/FormData.xsd");
                                nsMgr.AddNamespace("xsi", "http://www.w3.org/2001/XMLSchema-instance");
                                nsMgr.AddNamespace("addData", "http://www.abbyy.com/FlexiCapture/Schemas/Export/AdditionalFormData.xsd");
                                XmlNode oRootNode = resDoc.DocumentElement;
                                tempdata.TD_TEMPLATENAME = ProjectName;
                                tempdata.TD_CREATEDDATE = DateTime.Now;
                                tempdata.TD_RECORDSTATUS = 1;
                                tempdata.TD_INPUTIMAGE = mem_bytes;
                                List<TEMPLATECOORDIANATE> jdList = new List<TEMPLATECOORDIANATE>();

                                XmlNode nlNode = resDoc.DocumentElement.FirstChild;
                                if (TemplateName.ToUpper().Contains("PAYSTUB"))
                                {
                                    if (TemplateName.ToUpper().Contains("PAYSTUB") == true)
                                        strTemplatePath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "PaystubTemplate.HTML");

                                    PayStubTemplate.Load(strTemplatePath);
                                    int NodeIteration = 0;
                                    var sum = 0;

                                    var format = new NumberFormatInfo();
                                    format.NegativeSign = "-";
                                    format.NumberNegativePattern = 1;
                                    format.NumberDecimalSeparator = ".";
                                    format.NumberGroupSeparator = ",";

                                    ////Get Sum of _TaxPay
                                    XmlNodeList taxPay = resDoc.SelectNodes("//_TaxPay");
                                    decimal taxPaySum = 0;
                                    foreach (XmlNode tp in taxPay)
                                    {
                                        taxPaySum += decimal.Parse(taxPaySum.ToString(), NumberStyles.Number) + decimal.Parse(Common.Common.Parse(tp.InnerText.ToString()), NumberStyles.Number);
                                        //taxPaySum = Double.TryParse(taxPaySum, NumberStyles.AllowDecimalPoint | NumberStyles.AllowLeadingSign, format, out taxPaySum) + Double.TryParse(tp.InnerText, NumberStyles.AllowDecimalPoint | NumberStyles.AllowLeadingSign, format, out taxPaySum);
                                    }

                                    ////Get Sum of _TaxPayYTD
                                    XmlNodeList taxPayYTD = resDoc.SelectNodes("//_TaxPayYTD");
                                    decimal taxPaySumYTD = 0;
                                    foreach (XmlNode tpytd in taxPayYTD)
                                    {
                                        taxPaySumYTD += decimal.Parse(taxPaySumYTD.ToString(), NumberStyles.Number) + decimal.Parse(Common.Common.Parse(tpytd.InnerText.ToString()), NumberStyles.Number);
                                    }

                                    ////Get Sum of _NetPay
                                    XmlNodeList netPay = resDoc.SelectNodes("//_NetPay");
                                    decimal netPaySum = 0;
                                    foreach (XmlNode tp in netPay)
                                    {
                                        netPaySum += decimal.Parse(netPaySum.ToString(), NumberStyles.Number) + decimal.Parse(Common.Common.Parse(tp.InnerText.ToString()), NumberStyles.Number);
                                        //taxPaySum = Double.TryParse(taxPaySum, NumberStyles.AllowDecimalPoint | NumberStyles.AllowLeadingSign, format, out taxPaySum) + Double.TryParse(tp.InnerText, NumberStyles.AllowDecimalPoint | NumberStyles.AllowLeadingSign, format, out taxPaySum);
                                    }

                                    ////Get Sum of _NetPayYTD
                                    XmlNodeList netPayYTD = resDoc.SelectNodes("//_NetPayYTD");
                                    decimal netPaySumYTD = 0;
                                    foreach (XmlNode tpytd in netPayYTD)
                                    {
                                        netPaySumYTD += decimal.Parse(netPaySumYTD.ToString(), NumberStyles.Number) + decimal.Parse(Common.Common.Parse(tpytd.InnerText.ToString()), NumberStyles.Number);
                                    }

                                    ////Get Sum of _TaxPay
                                    XmlNodeList grossPay = resDoc.SelectNodes("//_GrossPay");
                                    decimal grossPaySum = 0;
                                    foreach (XmlNode tp in grossPay)
                                    {
                                        grossPaySum += decimal.Parse(grossPaySum.ToString(), NumberStyles.Number) + decimal.Parse(Common.Common.Parse(tp.InnerText.ToString()), NumberStyles.Number);
                                        //taxPaySum = Double.TryParse(taxPaySum, NumberStyles.AllowDecimalPoint | NumberStyles.AllowLeadingSign, format, out taxPaySum) + Double.TryParse(tp.InnerText, NumberStyles.AllowDecimalPoint | NumberStyles.AllowLeadingSign, format, out taxPaySum);
                                    }

                                    ////Get Sum of _GrossPayYTD
                                    XmlNodeList grossPayYTD = resDoc.SelectNodes("//_GrossPayYTD");
                                    decimal grossPaySumYTD = 0;
                                    foreach (XmlNode tpytd in grossPayYTD)
                                    {
                                        grossPaySumYTD += decimal.Parse(grossPaySumYTD.ToString(), NumberStyles.Number) + decimal.Parse(Common.Common.Parse(tpytd.InnerText.ToString()), NumberStyles.Number);
                                    }

                                    string[] SumArray = { "_TaxPay", "_TaxPayYTD", "_NetPay", "_NetPayYTD", "_GrossPay", "GrossPayYTD" };

                                    for (int i = 0; i < SumArray.Length; i++)
                                    {
                                        foreach (XmlNode nodes in nlNode.ChildNodes)
                                        {
                                            if (nodes.Name == SumArray[i])
                                            {

                                                XmlNode FindNodes = PayStubTemplate.SelectSingleNode(@"//node()[@id=""" + SumArray[i].ToString() + @"""]");
                                                XmlNode FindTextNodes = PayStubTemplate.SelectSingleNode(@"//node()[@id=""txt" + SumArray[i].ToString() + @"""]");

                                                if (nodes.Name == "_TaxPay")
                                                {
                                                    FindNodes.InnerText = taxPaySum.ToString();
                                                    if (FindTextNodes != null)
                                                        FindTextNodes.Attributes["value"].Value = taxPaySum.ToString();
                                                }
                                                else if (nodes.Name == "_TaxPayYTD")
                                                {
                                                    FindNodes.InnerText = taxPaySumYTD.ToString();
                                                    if (FindTextNodes != null)
                                                        FindTextNodes.Attributes["value"].Value = taxPaySumYTD.ToString();
                                                }
                                                if (nodes.Name == "_NetPay")
                                                {
                                                    FindNodes.InnerText = netPaySum.ToString();
                                                    if (FindTextNodes != null)
                                                        FindTextNodes.Attributes["value"].Value = netPaySum.ToString();
                                                }
                                                if (nodes.Name == "_NetPayYTD")
                                                {
                                                    FindNodes.InnerText = netPaySumYTD.ToString();
                                                    if (FindTextNodes != null)
                                                        FindTextNodes.Attributes["value"].Value = netPaySumYTD.ToString();
                                                }
                                                if (nodes.Name == "_GrossPay")
                                                {
                                                    FindNodes.InnerText = grossPaySum.ToString();
                                                    if (FindTextNodes != null)
                                                        FindTextNodes.Attributes["value"].Value = grossPaySum.ToString();
                                                }
                                                if (nodes.Name == "_GrossPayYTD")
                                                {
                                                    FindNodes.InnerText = grossPaySumYTD.ToString();
                                                    if (FindTextNodes != null)
                                                        FindTextNodes.Attributes["value"].Value = grossPaySumYTD.ToString();
                                                }

                                            }

                                        }
                                    }

                                    foreach (XmlNode node in nlNode.ChildNodes)
                                    {

                                        XmlNode SelectionLineNode = null;

                                        int PageIndex = 0;
                                        long Top = 0;
                                        long Left = 0;
                                        long Right = 0;
                                        long Bottom = 0;
                                        string NodeLineval = GetAttribute(node, "addData:BlockRef");

                                        if (NodeLineval != "")
                                        {
                                            SelectionLineNode = node.SelectSingleNode(@"//addData:Blocks[@Id=""" + NodeLineval + @"""]//addData:Rect", nsMgr);
                                            XmlNode SelectionIndex = node.SelectSingleNode(@"//addData:Blocks[@Id=""" + NodeLineval + @"""]", nsMgr);
                                            if (SelectionIndex != null)
                                            {
                                                PageIndex = Convert.ToInt32(SelectionIndex.FirstChild.Attributes.GetNamedItem("PageIndex").Value);
                                            }

                                            //Find Co-Ordinates
                                            if (SelectionLineNode != null)
                                            {

                                                Top = Convert.ToInt64(GetAttribute(SelectionLineNode, "Top"));
                                                Left = Convert.ToInt64(GetAttribute(SelectionLineNode, "Left"));
                                                Right = Convert.ToInt64(GetAttribute(SelectionLineNode, "Right"));
                                                Bottom = Convert.ToInt64(GetAttribute(SelectionLineNode, "Bottom"));
                                            }
                                        }
                                        BindPaystubNodewithDOM(node, Top, Left, Right, Bottom, TemplateName + Convert.ToString(PageIndex) + ".tif", nsMgr, NodeIteration);
                                        NodeIteration++;
                                    }
                                }
                                else
                                {
                                    ErrorMessage = "Template is not given";
                                    ViewBag.ErrorMessage = ErrorMessage;
                                }
                            }
                        }

                    }
                    catch (Exception ex)
                    {
                        logtext = ex.Message.ToString();
                        trnsobj.WriteStatusLog(logtext + "|" + "Error in LoadXML function");
                    }

                }
                ViewBag.Data = logtext;
            }
            catch (Exception e)
            {
                logtext = e.Message.ToString();
                trnsobj.WriteStatusLog(logtext + "|" + "Error in LoadXML function");

            }

            //return PartialView("LoanTable", LoanTemplate.OuterXml);
            //var res = new { Result = LoanTemplate.OuterXml, Image = ImageResult };
            //var res = new { Result = LoanTemplate.OuterXml, Image = ImagePath };
            return Json(PayStubTemplate.OuterXml, JsonRequestBehavior.AllowGet);
        }

        #endregion

        #region CreateNew

        public ActionResult CreateNew(string CategoryName)
        {
            ViewBag.CategoryName = CategoryName;
            TempData["Category"] = CategoryName;
            TempData.Keep("Category"); 

            TEMPLATEDATA processData = new TEMPLATEDATA();
            ViewBag.ClientId = new SelectList(GetClientDropDown(), "Value", "Text");
            ViewBag.TemplateId = new SelectList(GetTemplateDropDown(), "Value", "Text");
            ViewBag.CategoryId = new SelectList(GetCategoryDropDown(), "Value", "Text");
            if (processData == null)
            {
                return HttpNotFound();
            }
            return View(processData);
        }

        public ActionResult SearchCreateNew(string button)
        {
            string ErrorMessage = "";
            decimal filesize = 0;
            string strFileName = "";
            string[] ImageResult = { };
            string Category = string.Empty;
            string strPartialview = string.Empty;

            TEMPLATEDATA tempdata = new TEMPLATEDATA();
            TEMPLATEDATA templistdata = new TEMPLATEDATA();
            if (button == "" || button == null)
            {
                if (Request.Files.Count > 0)
                {
                    for (int i = 0; i < Request.Files.Count; i++)
                    {

                        HttpPostedFileBase file = Request.Files[i];
                        if (file != null)
                        {
                            byte[] imgData = new byte[file.ContentLength];
                            int result = file.InputStream.Read(imgData, 0, file.ContentLength);
                            strFileName = System.IO.Path.GetFileNameWithoutExtension(file.FileName).ToString();
                            //strFileName = file.FileName;

                            //File Extension
                            var supportedTypes = new[] { "jpg", "png", "gif", "tif", "tiff" };
                            var fileExt = System.IO.Path.GetExtension(file.FileName).Substring(1);
                            if (!supportedTypes.Contains(fileExt))
                            {
                                ErrorMessage = "File Extension Is InValid - Only Upload JPG/PNG/GIF/TIF File";
                                ViewBag.ErrorMessage = ErrorMessage;
                            }
                            else if (file.ContentLength > (filesize * 1024))
                            {
                                ErrorMessage = "File size Should Be UpTo " + filesize + "KB";
                                ViewBag.ErrorMessage = ErrorMessage;
                            }
                            else
                            {
                                ErrorMessage = "File Is Successfully Uploaded";
                                ViewBag.ErrorMessage = ErrorMessage;
                            }


                            //now convert byte[] to Base64
                            string inpBase64Data = Convert.ToBase64String(imgData);
                            OCRProcess.Request req = new OCRProcess.Request();
                            OCRProcess.Response resp = new OCRProcess.Response();
                            if (TempData["Category"] != null)
                            {
                                req.ProjectName = Convert.ToString(TempData["Category"]);
                                TempData.Keep("Category");
                                Category = req.ProjectName;
                            }
                            else
                                req.ProjectName = "SIG"; // ARGO,ZITTER Argo
                            req.Classification = OCRProcess.enumClassification.Bank_Documents; //ARGO--> BANK DOCUMENT
                            req.DocumentName = OCRProcess.enumClassification.Bank_Documents.ToString(); //Any Name
                            req.DocType = OCRProcess.DocType.Forms; //FORM
                            req.DocumentExtension = fileExt.ToUpper().ToString(); //TIFF,JPG ETC
                            req.InputDocument = inpBase64Data;//BASE64 IMAGE

                            try
                            {
                                resp = objClientOCRProcess.DoExtractUsingBase64(req, true);
                            }
                            catch (Exception ex)
                            {
                                resp = objClientOCRProcess.DoExtractUsingBase64(req, true);
                            }

                            string[] resultXML = resp.Document;
                            string[] resultTiff = resp.TiffFile;
                            ImageResult = resultTiff;
                            int Count = 1;
                            if (Category.ToUpper().Contains("ICR") == true || Category.ToUpper().Contains("PAYSTUB") == true || Category.ToUpper().Contains("APINVOICE") == true)
                            {
                                foreach (var image in ImageResult)
                                {
                                    string strPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Tif");
                                    if (!Directory.Exists(strPath))
                                        Directory.CreateDirectory(strPath);
                                    string filePath = Path.Combine(strPath, Category + Count + ".tif");
                                    System.IO.File.WriteAllBytes(filePath, Convert.FromBase64String(image));
                                    Count++;
                                }
                            }
                            //set the image path
                            String path = Server.MapPath("~/Images/Upload");
                            //combine the image path
                            string imgCombPath = Path.Combine(path, file.FileName);
                            //Check if directory exist
                            if (!System.IO.Directory.Exists(imgCombPath))
                            {
                                System.IO.Directory.CreateDirectory(imgCombPath); //Create directory if it doesn't exist
                            }
                            var imgPath = Path.Combine(Server.MapPath("~/Images/Upload/"), file.FileName);
                            try
                            {
                                for (int k = 1; k <= resultXML.Length; k++)
                                {
                                    if (resultXML[k - 1].ToString() != "")
                                    {
                                        byte[] mem_bytes = Convert.FromBase64String(resultXML[k - 1]);
                                        XmlDocument resDoc = new XmlDocument();
                                        using (var ms = new MemoryStream(mem_bytes))
                                        using (var reader = new StreamReader(ms))
                                        {
                                            while (!reader.EndOfStream && reader.Peek() > -1 && (char)reader.Peek() != '<')
                                                reader.Read();
                                            if (!reader.EndOfStream)
                                                resDoc.Load(reader);
                                            //Instantiate an XmlNamespaceManager object. 
                                            XmlNamespaceManager nsMgr = new XmlNamespaceManager(resDoc.NameTable);

                                            XPathNavigator nav = resDoc.CreateNavigator();
                                            XmlNamespaceManager nsmgr = new XmlNamespaceManager(nav.NameTable);

                                            // Retrieve the namespaces into a Generic dictionary with string keys.
                                            nsMgr.AddNamespace("form", "http://www.abbyy.com/FlexiCapture/Schemas/Export/FormData.xsd");
                                            nsMgr.AddNamespace("xsi", "http://www.w3.org/2001/XMLSchema-instance");
                                            nsMgr.AddNamespace("addData", "http://www.abbyy.com/FlexiCapture/Schemas/Export/AdditionalFormData.xsd");
                                            XmlNode oRootNode = resDoc.DocumentElement;
                                            tempdata.TD_TEMPLATENAME = ProjectName;
                                            tempdata.TD_CREATEDDATE = DateTime.Now;
                                            tempdata.TD_RECORDSTATUS = 1;

                                            tempdata.TD_INPUTIMAGE = mem_bytes;
                                            List<TEMPLATECOORDIANATE> jdList = new List<TEMPLATECOORDIANATE>();
                                            List<TEMPLATECOORDIANATE> jdLineList = new List<TEMPLATECOORDIANATE>();

                                            //GenericDataWithLineItem obj = new GenericDataWithLineItem();
                                            // List<TEMPLATEDATA> objData = new List<TEMPLATEDATA>();
                                            //Suganya for generic code 20th Dec 2018
                                            XmlNode nlNode = resDoc.DocumentElement.FirstChild;
                                            int row = -1, column = 0;
                                            foreach (XmlNode node in nlNode.ChildNodes)
                                            {
                                                bool isLineItem = false;
                                                string AttrName = node.Name;
                                                string AttrValue = node.InnerText;
                                                if (node.HasChildNodes)
                                                {
                                                    if (node.ChildNodes.Count > 1 || node.ChildNodes[0].NodeType == XmlNodeType.Element)
                                                    {
                                                        row++;
                                                        column = 0;
                                                        foreach (XmlNode childNode in node.ChildNodes)
                                                        {
                                                            isLineItem = true;
                                                            string AttrLineName = childNode.Name;
                                                            string AttrLineValue = childNode.InnerText;
                                                            TEMPLATECOORDIANATE jdLineItem = new TEMPLATECOORDIANATE();
                                                            jdLineItem.TC_TEMPLATECOORDIANATENAME = (childNode.Name.StartsWith("_")) ? childNode.Name.Substring(1) : childNode.Name;
                                                            jdLineItem.TC_TEMPLATECOORDINATEVALUE = AttrLineValue;
                                                            //jdLineItem.TC_CREATEDBY = SmartXtract.Controllers.LoginController.GlobalUser.USERID;
                                                            jdLineItem.TC_NODETYPE = "LINEITEM";
                                                            jdLineItem.TC_ROWPOSITION = row;
                                                            jdLineItem.TC_COLUMNPOSITION = column++;
                                                            jdLineItem.TC_RECORDSTATUS = 1;
                                                            jdLineItem.TC_FILENAME = Category + k + ".tif";

                                                            XmlNode SelectionLineNode = null;
                                                            string NodeLineval = GetAttribute(node, "addData:BlockRef");
                                                            if (NodeLineval != "")
                                                            {
                                                                SelectionLineNode = node.SelectSingleNode(@"//addData:Blocks[@Id=""" + NodeLineval + @"""]//addData:Rect", nsMgr);
                                                            }
                                                            //Find Co-Ordinates
                                                            if (SelectionLineNode != null)
                                                            {

                                                                jdLineItem.TC_TOP = Convert.ToDecimal(GetAttribute(SelectionLineNode, "Top"));
                                                                jdLineItem.TC_LEFT = Convert.ToDecimal(GetAttribute(SelectionLineNode, "Left"));
                                                                jdLineItem.TC_RIGHT = Convert.ToDecimal(GetAttribute(SelectionLineNode, "Right"));
                                                                jdLineItem.TC_BOTTOM = Convert.ToDecimal(GetAttribute(SelectionLineNode, "Bottom"));
                                                            }
                                                            jdList.Add(jdLineItem);
                                                            //templistdata.TEMPLATECOORDIANATE = jdLineList;
                                                            tempdata.TEMPLATECOORDIANATE = jdList;
                                                        }
                                                    }
                                                }
                                                if (!isLineItem)
                                                {
                                                    TEMPLATECOORDIANATE jd = new TEMPLATECOORDIANATE();
                                                    //TEMPLATECOORDIANATE jd = new TEMPLATECOORDIANATE();
                                                    jd.TC_TEMPLATECOORDIANATENAME = (node.Name.StartsWith("_")) ? node.Name.Substring(1) : node.Name;
                                                    jd.TC_TEMPLATECOORDINATEVALUE = AttrValue;
                                                    //jd.TC_CREATEDBY = SmartXtract.Controllers.LoginController.GlobalUser.USERID;
                                                    jd.TC_NODETYPE = "HEADER";
                                                    jd.TC_ROWPOSITION = 0;
                                                    jd.TC_COLUMNPOSITION = 0;
                                                    jd.TC_RECORDSTATUS = 1;
                                                    jd.TC_FILENAME = Category + k + ".tif";

                                                    XmlNode SelectionNode = null;
                                                    string Nodeval = GetAttribute(node, "addData:BlockRef");
                                                    if (Nodeval != "")
                                                    {
                                                        SelectionNode = node.SelectSingleNode(@"//addData:Blocks[@Id=""" + Nodeval + @"""]//addData:Rect", nsMgr);
                                                    }
                                                    //Find Co-Ordinates
                                                    if (SelectionNode != null)
                                                    {

                                                        jd.TC_TOP = Convert.ToDecimal(GetAttribute(SelectionNode, "Top"));
                                                        jd.TC_LEFT = Convert.ToDecimal(GetAttribute(SelectionNode, "Left"));
                                                        jd.TC_RIGHT = Convert.ToDecimal(GetAttribute(SelectionNode, "Right"));
                                                        jd.TC_BOTTOM = Convert.ToDecimal(GetAttribute(SelectionNode, "Bottom"));
                                                    }
                                                    jdList.Add(jd);
                                                    tempdata.TEMPLATECOORDIANATE = jdList;

                                                }
                                            }
                                        }
                                    }
                                }

                            }
                            catch (Exception ex)
                            {
                                logtext = ex.Message.ToString();
                                trnsobj.WriteStatusLog(logtext + "|" + "Error in LoadXML function");
                            }
                        }
                    }
                }
            }
            else
            {
                var filnam = button.ToString();

                var paths = Server.MapPath("~/Sample");
                var fullpath = Path.Combine(paths, filnam);
                string fileExt = Path.GetExtension(fullpath);

                string pathss = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Sample") + "\\" + filnam;
                byte[] imgData = ImageToBinary(pathss);

                //now convert byte[] to Base64
                string inpBase64Data = Convert.ToBase64String(imgData);
                OCRProcess.Request req = new OCRProcess.Request();
                OCRProcess.Response resp = new OCRProcess.Response();
                if (TempData["Category"] != null)
                {
                    req.ProjectName = Convert.ToString(TempData["Category"]);
                    TempData.Keep("Category");
                    Category = req.ProjectName;
                }
                else
                    req.ProjectName = "SIG"; // ARGO,ZITTER Argo
                req.Classification = OCRProcess.enumClassification.Bank_Documents; //ARGO--> BANK DOCUMENT
                req.DocumentName = OCRProcess.enumClassification.Bank_Documents.ToString(); //Any Name
                req.DocType = OCRProcess.DocType.Forms; //FORM
                req.DocumentExtension = fileExt.ToUpper().ToString(); //TIFF,JPG ETC
                req.InputDocument = inpBase64Data;//BASE64 IMAGE

                try
                {
                    resp = objClientOCRProcess.DoExtractUsingBase64(req, true);
                }
                catch (Exception ex)
                {
                    resp = objClientOCRProcess.DoExtractUsingBase64(req, true);
                }

                string[] resultXML = resp.Document;
                string[] resultTiff = resp.TiffFile;
                ImageResult = resultTiff;
                int Count = 1;
                if (Category.ToUpper().Contains("ICR") == true || Category.ToUpper().Contains("PAYSTUB") == true)
                {
                    foreach (var image in ImageResult)
                    {
                        string strPath = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Tif");
                        if (!Directory.Exists(strPath))
                            Directory.CreateDirectory(strPath);
                        string filePath = Path.Combine(strPath, Category + Count + ".tif");
                        System.IO.File.WriteAllBytes(filePath, Convert.FromBase64String(image));
                        // Count++;
                    }
                }
                //set the image path
                String path = Server.MapPath("~/Images/Upload");
                //combine the image path
                string imgCombPath = Path.Combine(path, filnam);
                //Check if directory exist
                if (!System.IO.Directory.Exists(imgCombPath))
                {
                    System.IO.Directory.CreateDirectory(imgCombPath); //Create directory if it doesn't exist
                }
                var imgPath = Path.Combine(Server.MapPath("~/Images/Upload/"), filnam);
                try
                {
                    for (int k = 1; k <= resultXML.Length; k++)
                    {
                        if (resultXML[k].ToString() != "")
                        {
                            byte[] mem_bytes = Convert.FromBase64String(resultXML[k]);
                            XmlDocument resDoc = new XmlDocument();
                            using (var ms = new MemoryStream(mem_bytes))
                            using (var reader = new StreamReader(ms))
                            {
                                while (!reader.EndOfStream && reader.Peek() > -1 && (char)reader.Peek() != '<')
                                    reader.Read();
                                if (!reader.EndOfStream)
                                    resDoc.Load(reader);
                                //Instantiate an XmlNamespaceManager object. 
                                XmlNamespaceManager nsMgr = new XmlNamespaceManager(resDoc.NameTable);

                                XPathNavigator nav = resDoc.CreateNavigator();
                                XmlNamespaceManager nsmgr = new XmlNamespaceManager(nav.NameTable);

                                // Retrieve the namespaces into a Generic dictionary with string keys.
                                nsMgr.AddNamespace("form", "http://www.abbyy.com/FlexiCapture/Schemas/Export/FormData.xsd");
                                nsMgr.AddNamespace("xsi", "http://www.w3.org/2001/XMLSchema-instance");
                                nsMgr.AddNamespace("addData", "http://www.abbyy.com/FlexiCapture/Schemas/Export/AdditionalFormData.xsd");
                                XmlNode oRootNode = resDoc.DocumentElement;
                                tempdata.TD_TEMPLATENAME = ProjectName;
                                tempdata.TD_CREATEDDATE = DateTime.Now;
                                tempdata.TD_RECORDSTATUS = 1;

                                tempdata.TD_INPUTIMAGE = mem_bytes;
                                List<TEMPLATECOORDIANATE> jdList = new List<TEMPLATECOORDIANATE>();
                                List<TEMPLATECOORDIANATE> jdLineList = new List<TEMPLATECOORDIANATE>();

                                XmlNode nlNode = resDoc.DocumentElement.FirstChild;
                                int row = -1, column = 0;
                                foreach (XmlNode node in nlNode.ChildNodes)
                                {
                                    bool isLineItem = false;
                                    string AttrName = node.Name;
                                    string AttrValue = node.InnerText;
                                    if (node.HasChildNodes)
                                    {
                                        if (node.ChildNodes.Count > 1 || node.ChildNodes[0].NodeType == XmlNodeType.Element)
                                        {
                                            row++;
                                            column = 0;
                                            foreach (XmlNode childNode in node.ChildNodes)
                                            {
                                                isLineItem = true;
                                                string AttrLineName = childNode.Name;
                                                string AttrLineValue = childNode.InnerText;
                                                TEMPLATECOORDIANATE jdLineItem = new TEMPLATECOORDIANATE();
                                                jdLineItem.TC_TEMPLATECOORDIANATENAME = (childNode.Name.StartsWith("_")) ? childNode.Name.Substring(1) : childNode.Name;
                                                jdLineItem.TC_TEMPLATECOORDINATEVALUE = AttrLineValue;
                                                //jdLineItem.TC_CREATEDBY = SmartXtract.Controllers.LoginController.GlobalUser.USERID;
                                                jdLineItem.TC_NODETYPE = "LINEITEM";
                                                jdLineItem.TC_ROWPOSITION = row;
                                                jdLineItem.TC_COLUMNPOSITION = column++;
                                                jdLineItem.TC_RECORDSTATUS = 1;
                                                jdLineItem.TC_FILENAME = Category + k + ".tif";
                                                XmlNode SelectionLineNode = null;
                                                string NodeLineval = GetAttribute(node, "addData:BlockRef");
                                                if (NodeLineval != "")
                                                {
                                                    SelectionLineNode = node.SelectSingleNode(@"//addData:Blocks[@Id=""" + NodeLineval + @"""]//addData:Rect", nsMgr);
                                                }
                                                //Find Co-Ordinates
                                                if (SelectionLineNode != null)
                                                {

                                                    jdLineItem.TC_TOP = Convert.ToDecimal(GetAttribute(SelectionLineNode, "Top"));
                                                    jdLineItem.TC_LEFT = Convert.ToDecimal(GetAttribute(SelectionLineNode, "Left"));
                                                    jdLineItem.TC_RIGHT = Convert.ToDecimal(GetAttribute(SelectionLineNode, "Right"));
                                                    jdLineItem.TC_BOTTOM = Convert.ToDecimal(GetAttribute(SelectionLineNode, "Bottom"));
                                                }
                                                jdList.Add(jdLineItem);
                                                //templistdata.TEMPLATECOORDIANATE = jdLineList;
                                                tempdata.TEMPLATECOORDIANATE = jdList;
                                            }
                                        }
                                    }
                                    if (!isLineItem)
                                    {
                                        TEMPLATECOORDIANATE jd = new TEMPLATECOORDIANATE();
                                        //TEMPLATECOORDIANATE jd = new TEMPLATECOORDIANATE();
                                        jd.TC_TEMPLATECOORDIANATENAME = (node.Name.StartsWith("_")) ? node.Name.Substring(1) : node.Name;
                                        jd.TC_TEMPLATECOORDINATEVALUE = AttrValue;
                                        // jd.TC_CREATEDBY = SmartXtract.Controllers.LoginController.GlobalUser.USERID;
                                        jd.TC_NODETYPE = "HEADER";
                                        jd.TC_ROWPOSITION = 0;
                                        jd.TC_COLUMNPOSITION = 0;
                                        jd.TC_RECORDSTATUS = 1;
                                        jd.TC_FILENAME = Category + k + ".tif";
                                        XmlNode SelectionNode = null;
                                        string Nodeval = GetAttribute(node, "addData:BlockRef");
                                        if (Nodeval != "")
                                        {
                                            SelectionNode = node.SelectSingleNode(@"//addData:Blocks[@Id=""" + Nodeval + @"""]//addData:Rect", nsMgr);
                                        }
                                        //Find Co-Ordinates
                                        if (SelectionNode != null)
                                        {

                                            jd.TC_TOP = Convert.ToDecimal(GetAttribute(SelectionNode, "Top"));
                                            jd.TC_LEFT = Convert.ToDecimal(GetAttribute(SelectionNode, "Left"));
                                            jd.TC_RIGHT = Convert.ToDecimal(GetAttribute(SelectionNode, "Right"));
                                            jd.TC_BOTTOM = Convert.ToDecimal(GetAttribute(SelectionNode, "Bottom"));
                                        }
                                        jdList.Add(jd);
                                        tempdata.TEMPLATECOORDIANATE = jdList;

                                    }
                                }
                            }
                        }
                    }
                }
                catch (Exception ex)
                {
                    logtext = ex.Message.ToString();
                    trnsobj.WriteStatusLog(logtext + "|" + "Error in LoadXML function");
                }
            }
            ViewBag.Data = logtext;
            //if (Category.ToUpper().Contains("GPC") == true || Category.ToUpper().Contains("APINVOICE") == true)
            //    strPartialview = "SearchPdfTextDetails";
            //else
            strPartialview = "SearchCreateDetails";
            return PartialView(strPartialview, tempdata);
        }

        #endregion

        #region PDFXtract

        public ActionResult TextPdfExtraction(string CategoryName)
        {
            ViewBag.CategoryName = CategoryName;
            TempData["Category"] = CategoryName;
            TempData.Keep("Category");


            //ViewBag.TemplateId = new SelectList(templatecomp.GetTemplateDropdown(), "TemplateID", "VendorName");

            return View("TextPdf");
        }

        #endregion

        #region AllDropdown
        public IEnumerable<SelectListItem> GetClientDropDown()
        {

            List<SelectListItem> list = new List<SelectListItem>();
            //list.Add(new SelectListItem()
            //{
            //    Value = "0",
            //    Text = "--- Select Client ---"
            //});
            list.Add(new SelectListItem()
            {
                Value = "1",
                Text = "Yes Bank"
            });
            list.Add(new SelectListItem()
            {
                Value = "2",
                Text = "New SBI"
            });
            list.Add(new SelectListItem()
            {
                Value = "3",
                Text = "ADBC Bank"
            });

            return new SelectList(list, "Value", "Text");
        }

        public IEnumerable<SelectListItem> GetProcessDropDown()
        {

            List<SelectListItem> list = new List<SelectListItem>();
            //list.Add(new SelectListItem()
            //{
            //    Value = "0",
            //    Text = "--- Select Process ---"
            //});
            list.Add(new SelectListItem()
            {
                Value = "1",
                Text = "Key 1"
            });
            list.Add(new SelectListItem()
            {
                Value = "2",
                Text = "Key 2"
            });
            list.Add(new SelectListItem()
            {
                Value = "3",
                Text = "Implementation"
            });

            return new SelectList(list, "Value", "Text");
        }

        public IEnumerable<SelectListItem> GetCategoryDropDown()
        {

            List<SelectListItem> list = new List<SelectListItem>();
            //list.Add(new SelectListItem()
            //{
            //    Value = "0",
            //    Text = "--- Select Process ---"
            //});
            list.Add(new SelectListItem()
            {
                Value = "1",
                Text = "Formulary"
            });
            list.Add(new SelectListItem()
            {
                Value = "2",
                Text = "PharmacyPolicy"
            });

            return new SelectList(list, "Value", "Text");
        }

        public IEnumerable<SelectListItem> GetTemplateDropDown()
        {

            List<SelectListItem> list = new List<SelectListItem>();
            //list.Add(new SelectListItem()
            //{
            //    Value = "0",
            //    Text = "--- Select Process ---"
            //});
            list.Add(new SelectListItem()
            {
                Value = "1",
                Text = "Celegene"
            });
            list.Add(new SelectListItem()
            {
                Value = "2",
                Text = "Cigna"
            });
            list.Add(new SelectListItem()
            {
                Value = "3",
                Text = "FebBlue"
            });
            list.Add(new SelectListItem()
            {
                Value = "4",
                Text = "Newyork"
            });
            list.Add(new SelectListItem()
            {
                Value = "5",
                Text = "BCBS"
            });
            list.Add(new SelectListItem()
            {
                Value = "6",
                Text = "BCBSMI"
            });
            list.Add(new SelectListItem()
            {
                Value = "7",
                Text = "Anthem"
            });
            list.Add(new SelectListItem()
            {
                Value = "8",
                Text = "Inland Empire"
            });
            list.Add(new SelectListItem()
            {
                Value = "9",
                Text = "Kaiser"
            });
            list.Add(new SelectListItem()
            {
                Value = "10",
                Text = "Harvard"
            });
            return new SelectList(list, "Value", "Text");
        }

        public IEnumerable<SelectListItem> GetTextTemplateDropDown()
        {
            List<SelectListItem> list = new List<SelectListItem>();
            list.Add(new SelectListItem()
            {
                Value = "1",
                Text = "CASTROL OIL NZ LTD"
            });
            list.Add(new SelectListItem()
            {
                Value = "2",
                Text = "DISC BRAKES AUSTRALIA"
            });
            return new SelectList(list, "Value", "Text");
        }
        #endregion

        #region OtherMethods

        public void BindNodewithDOM(XmlNode Node, long Top, long Left, long Right, long Bottom, string ImageName, XmlNamespaceManager nsmgr, int NodeIteration)
        {
            if (Node != null)
            {
                if (Node.NodeType == XmlNodeType.Element)
                {
                    if (Node.HasChildNodes)
                    {
                        int childcount = 0;
                        foreach (XmlNode ChildNode in Node.ChildNodes)
                        {
                            int PageIndex = 0;
                            long ChildTop = 0;
                            long ChildLeft = 0;
                            long ChildRight = 0;
                            long ChildBottom = 0;
                            XmlNode SelectionLineNode = null;
                            string NodeLineval = GetAttribute(ChildNode, "addData:BlockRef");
                            if (NodeLineval != "")
                            {
                                //XmlNamespaceManager nsMgr = new XmlNamespaceManager();
                                SelectionLineNode = ChildNode.SelectSingleNode(@"//addData:Blocks[@Id=""" + NodeLineval + @"""]//addData:Rect", nsmgr);
                                XmlNode SelectionIndex = ChildNode.SelectSingleNode(@"//addData:Blocks[@Id=""" + NodeLineval + @"""]", nsmgr);
                                if (SelectionIndex != null)
                                {
                                    PageIndex = Convert.ToInt32(SelectionIndex.FirstChild.Attributes.GetNamedItem("PageIndex").Value);
                                }
                            }
                            //Find Co-Ordinates
                            if (SelectionLineNode != null)
                            {

                                ChildTop = Convert.ToInt64(GetAttribute(SelectionLineNode, "Top"));
                                ChildLeft = Convert.ToInt64(GetAttribute(SelectionLineNode, "Left"));
                                ChildRight = Convert.ToInt64(GetAttribute(SelectionLineNode, "Right"));
                                ChildBottom = Convert.ToInt64(GetAttribute(SelectionLineNode, "Bottom"));
                            }
                            BindNodewithDOM(ChildNode, ChildLeft, ChildTop, ChildRight, ChildBottom, ImageName, nsmgr, NodeIteration + childcount);
                            childcount++;
                        }
                        XmlNode FindNode = LoanTemplate.SelectSingleNode(@"//node()[@id=""" + Node.Name + @"""]");
                        //XmlNode FindTextNode = LoanTemplate.SelectSingleNode(@"//node()[@id=""" + Node.Name + @"""]");
                        var FindTextNode = LoanTemplate.SelectSingleNode(@"//node()[@id=""txt" + Node.Name + @"""]");
                        if (FindNode != null)
                        {
                            string TypeAttribute = "";
                            if (FindNode.Attributes.GetNamedItem("Type") != null)
                            {
                                TypeAttribute = FindNode.Attributes.GetNamedItem("Type").Value;
                            }
                            if (TypeAttribute == "")
                            {
                                FindNode.InnerText = Node.InnerText;
                                if (FindTextNode != null)
                                {
                                    FindTextNode.Attributes["value"].Value = Node.InnerText;
                                    FindTextNode.Attributes["onclick"].Value = "SetImageCropping(" + Left + "," + Top + "," + Right + "," + Bottom + ",'" + ImageName + "');";
                                    string id = Node.Name;
                                    FindTextNode.Attributes["onchange"].Value = "SetText('#txt" + id + "','#" + id + "');";
                                }
                            }
                            else
                            {
                                XmlNode tr = LoanTemplate.CreateElement("tr");
                                int i = 0;
                                foreach (XmlNode LineChildNode in Node.ChildNodes)
                                {
                                    //XmlNode td = LoanTemplate.CreateElement("td");
                                    //td.InnerText = LineChildNode.InnerText;
                                    //tr.AppendChild(td);
                                    XmlNode td = LoanTemplate.CreateElement("td");
                                    //Create an input type dynamically.
                                    var element = LoanTemplate.CreateElement("input");
                                    //Assign different attributes to the element.
                                    element.SetAttribute("type", "text");
                                    element.SetAttribute("value", LineChildNode.InnerText);
                                    string id = LineChildNode.Name.Replace(" ", "") + NodeIteration + i;
                                    element.SetAttribute("id", "txt" + id);
                                    //element.SetAttribute("onclick", "SetImageCropping('"+Top+"','"+Left+ "','" + Right + "','" + Bottom + "','" + Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"Tif",ImageName).Replace("\\","\\\\") + "');");
                                    element.SetAttribute("onclick", "SetImageCropping('" + Left + "','" + Top + "','" + Right + "','" + Bottom + "','" + ImageName + "');");
                                    element.SetAttribute("onchange", "SetText('#txt" + id + "','#lbl" + id + "');");
                                    element.SetAttribute("class", "autohidetextboxvisible col form-control");
                                    var lbl = LoanTemplate.CreateElement("label");
                                    lbl.SetAttribute("id", "lbl" + id);
                                    lbl.SetAttribute("style", "display:none;");
                                    lbl.InnerText = LineChildNode.InnerText;
                                    td.AppendChild(element);
                                    td.AppendChild(lbl);
                                    tr.AppendChild(td);
                                    i++;
                                }
                                if (tr.HasChildNodes)
                                {
                                    FindNode.AppendChild(tr);
                                    if (FindTextNode != null)
                                        FindTextNode.AppendChild(tr);
                                }
                            }
                        }
                        else
                        {

                        }
                    }
                    else
                    {

                    }
                }
            }
        }

        public void BindPaystubNodewithDOM(XmlNode Node, long Top, long Left, long Right, long Bottom, string ImageName, XmlNamespaceManager nsmgr, int NodeIteration)
        {
            if (Node != null)
            {
                if (Node.NodeType == XmlNodeType.Element)
                {
                    if (Node.HasChildNodes)
                    {
                        int childcount = 0;
                        foreach (XmlNode ChildNode in Node.ChildNodes)
                        {
                            int PageIndex = 0;
                            long ChildTop = 0;
                            long ChildLeft = 0;
                            long ChildRight = 0;
                            long ChildBottom = 0;
                            XmlNode SelectionLineNode = null;
                            string NodeLineval = GetAttribute(ChildNode, "addData:BlockRef");
                            if (NodeLineval != "")
                            {
                                //XmlNamespaceManager nsMgr = new XmlNamespaceManager();
                                SelectionLineNode = ChildNode.SelectSingleNode(@"//addData:Blocks[@id=""" + NodeLineval + @"""]//addData:Rect", nsmgr);
                                XmlNode SelectionIndex = ChildNode.SelectSingleNode(@"//addData:Blocks[@id=""" + NodeLineval + @"""]", nsmgr);
                                if (SelectionIndex != null)
                                {
                                    PageIndex = Convert.ToInt32(SelectionIndex.FirstChild.Attributes.GetNamedItem("PageIndex").Value);
                                }
                            }
                            //Find Co-Ordinates
                            if (SelectionLineNode != null)
                            {

                                ChildTop = Convert.ToInt64(GetAttribute(SelectionLineNode, "Top"));
                                ChildLeft = Convert.ToInt64(GetAttribute(SelectionLineNode, "Left"));
                                ChildRight = Convert.ToInt64(GetAttribute(SelectionLineNode, "Right"));
                                ChildBottom = Convert.ToInt64(GetAttribute(SelectionLineNode, "Bottom"));
                            }
                            BindPaystubNodewithDOM(ChildNode, ChildLeft, ChildTop, ChildRight, ChildBottom, ImageName, nsmgr, NodeIteration + childcount);
                            childcount++;
                        }
                        XmlNode FindNode = PayStubTemplate.SelectSingleNode(@"//node()[@id=""" + Node.Name + @"""]");
                        //XmlNode FindTextNode = PayStubTemplate.SelectSingleNode(@"//node()[@id=""" + Node.Name + @"""]");
                        var FindTextNode = PayStubTemplate.SelectSingleNode(@"//node()[@id=""txt" + Node.Name + @"""]");
                        if (FindNode != null)
                        {
                            string TypeAttribute = "";
                            if (FindNode.Attributes.GetNamedItem("Type") != null)
                            {
                                TypeAttribute = FindNode.Attributes.GetNamedItem("Type").Value;
                            }
                            if (TypeAttribute == "")
                            {
                                FindNode.InnerText = Node.InnerText;
                                if (FindTextNode != null)
                                {
                                    FindTextNode.Attributes["value"].Value = Node.InnerText;
                                    FindTextNode.Attributes["onclick"].Value = "SetImageCropping(" + Left + "," + Top + "," + Right + "," + Bottom + ",'" + ImageName + "');";
                                    string id = Node.Name;
                                    FindTextNode.Attributes["onchange"].Value = "SetText('#txt" + id + "','#" + id + "');";
                                }
                            }
                            else
                            {
                                XmlNode tr = PayStubTemplate.CreateElement("tr");
                                int i = 0;
                                foreach (XmlNode LineChildNode in Node.ChildNodes)
                                {
                                    //XmlNode td = PayStubTemplate.CreateElement("td");
                                    //td.InnerText = LineChildNode.InnerText;
                                    //tr.AppendChild(td);
                                    XmlNode td = PayStubTemplate.CreateElement("td");
                                    //Create an input type dynamically.
                                    var element = PayStubTemplate.CreateElement("input");
                                    //Assign different attributes to the element.
                                    element.SetAttribute("type", "text");
                                    element.SetAttribute("value", LineChildNode.InnerText);
                                    string id = LineChildNode.Name.Replace(" ", "") + NodeIteration + i;
                                    element.SetAttribute("id", "txt" + id);
                                    //element.SetAttribute("onclick", "SetImageCropping('"+Top+"','"+Left+ "','" + Right + "','" + Bottom + "','" + Path.Combine(AppDomain.CurrentDomain.BaseDirectory,"Tif",ImageName).Replace("\\","\\\\") + "');");
                                    element.SetAttribute("onclick", "SetImageCropping('" + Left + "','" + Top + "','" + Right + "','" + Bottom + "','" + ImageName + "');");
                                    element.SetAttribute("onchange", "SetText('#txt" + id + "','#lbl" + id + "');");
                                    element.SetAttribute("class", "autohidetextboxvisible col form-control");
                                    var lbl = PayStubTemplate.CreateElement("label");
                                    lbl.SetAttribute("id", "lbl" + id);
                                    lbl.SetAttribute("style", "display:none;");
                                    lbl.InnerText = LineChildNode.InnerText;
                                    td.AppendChild(element);
                                    td.AppendChild(lbl);
                                    tr.AppendChild(td);
                                    i++;
                                }
                                if (tr.HasChildNodes)
                                {
                                    FindNode.AppendChild(tr);
                                    if (FindTextNode != null)
                                        FindTextNode.AppendChild(tr);
                                }
                            }
                        }
                        else
                        {

                        }
                    }
                    else
                    {

                    }
                }
            }
        }


        public static byte[] ImageToBinary(string imagePath)
        {
            FileStream fS = new FileStream(imagePath, FileMode.Open, FileAccess.Read);
            byte[] b = new byte[fS.Length];
            fS.Read(b, 0, (int)fS.Length);
            fS.Close();
            return b;
        }

        private void TransformProcess(string Transflag)
        {
            logtext = "TransformProcess function inititated";
            trnsobj.WriteStatusLog(logtext);

            try
            {
                //string path = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "Images")  + "\\" + "Tiger.jpg";

                strBasePath = ConfigurationManager.AppSettings["BasePath"].ToString();
                strCleanupPath = FullpageOCRPath(ConfigurationManager.AppSettings["OcrProcess"].ToString());
                strOCRProcessPath = FullpageOCRPath(ConfigurationManager.AppSettings["XMLCleanup"].ToString());
                strXMLoutputPath = FullpageOCRPath(ConfigurationManager.AppSettings["XMLOutput"].ToString());
                ProjectName = FullpageOCRPath(ConfigurationManager.AppSettings["Export"].ToString());
                //ValidationFile = ConfigurationManager.AppSettings["ValidationFile"].ToString();


                //strBasePath = hdnBasePath.Value;
                //strCleanupPath = hdnXMLCleanupPath.Value;
                //strOCRProcessPath = hdnOcrProcessPath.Value;
                //strXMLoutputPath = hdnxmloutpath.Value;
                //ProjectName = hdnProject.Value;

                if (!Directory.Exists(strCleanupPath))
                    Directory.CreateDirectory(strCleanupPath);

                if (!Directory.Exists(strOCRProcessPath))
                    Directory.CreateDirectory(strOCRProcessPath);

                if (!Directory.Exists(strXMLoutputPath))
                    Directory.CreateDirectory(strXMLoutputPath);

                Session["project"] = "ZitterFormularies1";

                Transform trnsobj = new Transform();
                ViewMode = "";
                Session["ViewMode"] = ViewMode;

                ///Commented by kingsleen
                //if(Transflag == "Yes")
                //{
                //    if(drpocr.SelectedValue == "0")
                //    {
                //        trnsobj.OCRFRPRocess(strBasePath, strOCRProcessPath);
                //    }
                //    else
                //        trnsobj.ConvertFile(strBasePath, strOCRProcessPath, Template, ProjectName);
                //}
                ///Added by kingsleen from above commented
                trnsobj.ConvertFile(strBasePath, strOCRProcessPath, Template, ProjectName);

                PagePos = 0;
                ///Commented by kingsleen
                //imgextractiondetails.Visible = false;
                //string outputfile;
                //if(ProjectName.ToLower() == "zitter")
                //{
                //    Zitter zs = new Zitter();
                //    outputfile = zs.Preprocess(strOCRProcessPath, strCleanupPath, strXMLoutputPath);
                //}
                //imgextractiondetails.Visible = true;
                GetXMLOutput(strXMLoutputPath);
                //divPagination.Attributes.Add("style", "display:block;");
            }
            catch (Exception ex)
            {
                logtext = ex.Message.ToString();
                trnsobj.WriteStatusLog(logtext + "|" + "Error in transform process");
            }

        }
        private TableCell DisplayData(String ID, String value, string left, string top, int width, int height, string Panel, XmlNode ChildNode)
        {
            TableCell td = new TableCell();
            TextBox txtLineItem = new TextBox();
            txtLineItem.Attributes.Add("style", "margin: 5px 0px;border: 1px solid rgb(142, 177, 212);text-indent: 5px; background-color: white;");
            try
            {
                String sProject = "";
                sProject = "Domex";

                //if(sProject.ToUpper() == "EXPERIAN")
                //    value = value.Replace("\n\r", "<br/>").Replace("\n", "<br/>").Replace("\r", "<br/>");
                logtext = "Displaydata initiated";
                trnsobj.WriteStatusLog(logtext);

                txtLineItem.ID = ID;
                txtLineItem.Text = value;
                 
                txtLineItem.EnableViewState = true;


                ImageInfo imgInfo = new ImageInfo();
                int.TryParse(GetAttribute(ChildNode, "Left", ""), out imgInfo.Left);
                int.TryParse(GetAttribute(ChildNode, "Top", ""), out imgInfo.Top);
                int.TryParse(GetAttribute(ChildNode, "Right", ""), out imgInfo.Right);
                int.TryParse(GetAttribute(ChildNode, "Bottom", ""), out imgInfo.Bottom);

                txtLineItem.Width = imgInfo.Right - imgInfo.Left;
                txtLineItem.Height = imgInfo.Bottom - imgInfo.Top;


                if (txtLineItem.Width.Value > 150)
                {
                    txtLineItem.Width = 150;
                    //txtLineItem.TextMode = TextBoxMode.MultiLine;
                    //txtLineItem.Height = 100;
                }
                else if (txtLineItem.Width.Value < 50)
                {
                    txtLineItem.Width = 50;
                }
                if (txtLineItem.Height.Value > 40 && txtLineItem.TextMode != TextBoxMode.MultiLine)
                {
                    txtLineItem.Height = 40;
                }
                txtLineItem.Width = 150;
                txtLineItem.Height = 40;
                txtLineItem.Font.Bold = true;
                txtLineItem.Font.Size = 10;
                if (txtLineItem.Text.Contains("\n") || txtLineItem.Text.Contains("\r"))
                {
                    //txtLineItem.Width = 300;
                    txtLineItem.Width = 150;
                    txtLineItem.TextMode = TextBoxMode.MultiLine;
                    txtLineItem.Height = 100;
                }


                //txtLineItem.Height = height;
                String sImgFileName = GetAttribute(ChildNode, "FileName");
                string TestID = ID;
                txtLineItem.Attributes.Add("runat", "server");
                txtLineItem.Attributes.Add("OnClick", "SetImageCropping(" + "'" + imgInfo.Left + "'" + "," + imgInfo.Top + "," + imgInfo.Right + "," + imgInfo.Bottom + ",'" + sImgFileName + "');");

                td.Controls.Add(txtLineItem);
                TextBoxProperty(txtLineItem, ChildNode, "leave");

                string innerText = ChildNode.InnerText.ToString() ?? string.Empty;

                string ctrlName = "";
                string ctrlValue = "";
                String ProjectName = "Domex";
                string ctrlID;
                if (ProjectName.ToUpper() == "ARGO")
                {
                    ctrlID = GetAttribute(ChildNode, "UniqueID");
                    ctrlName = "#MainContent_" + ctrlID + "|";
                    ctrlValue += ModifyValue(ChildNode, ctrlID) + "|";
                    //ctrlValue = ChildNode.InnerText + "|";
                }
                else if (ProjectName.ToUpper() == "EXPERIAN")
                {
                    ctrlID = GetAttribute(ChildNode, "UniqueID");
                    ctrlName = "#MainContent_" + ctrlID + "|";
                    ctrlValue += ModifyValue(ChildNode, ctrlID) + "|";
                }
                else
                {
                    foreach (XmlNode currNode in ChildNode.ParentNode)
                    {
                        ctrlID = GetAttribute(currNode, "UniqueID");

                        if (ctrlID.Trim() != "")
                        {
                            ctrlName += "#MainContent_" + ctrlID + "|";
                            ctrlValue += ModifyValue(currNode, ctrlID) + "|";
                            //if(ctrlValue.Contains("600-300 mg"))
                            //{
                            //    string t = ctrlValue;
                            //}
                            //ctrlValue += currNode.InnerText + "|";
                        }
                    }
                }
                //string ColorFlag = "false";
                if (ViewMode.ToUpper() != "VERIFICATION")
                    ColorFlag = "false";


                txtLineItem.Attributes.Add("Onfocusin", "CallFocus(" + "'" + ctrlName + "')");
                txtLineItem.Attributes.Add("onfocusout", "CallBlur(" + "'" + ctrlName + "','" + Cleanup(ctrlValue) + "','" + ColorFlag + "')");

            }
            catch (Exception ex)
            {
                logtext = ex.Message.ToString();
                trnsobj.WriteStatusLog(logtext + "|" + "Error in function Displaydata");
            }

            return td;
        }
        public string ModifyValue(XmlNode Node, string ID)
        {
            XmlNode ModifyNode = Node.SelectSingleNode(@"//modifyarea//node()[@colname=""" + ID + @"""]");

            if (ModifyNode != null)
            {

                return ModifyNode.InnerText.Replace("\n", " ").Replace("\r", "");
            }
            else
                return Node.InnerText.Replace("\n", " ").Replace("\r", "");

        }
        public string Cleanup(string strData)
        {
            strData = strData.Replace("'", "\"");
            return strData;
        }
        public String GetAttribute(XmlNode SelectNode, String AttrName, String URL)
        {
            logtext = "GetAttribute initiated";
            trnsobj.WriteStatusLog(logtext);
            String sReturn = "";
            try
            {
                if (SelectNode != null)
                {

                    if (SelectNode.Attributes.GetNamedItem(AttrName, URL) != null)
                    {
                        return SelectNode.Attributes.GetNamedItem(AttrName, URL).Value;
                    }
                }

            }
            catch (Exception ex)
            {
                logtext = ex.Message.ToString();
                trnsobj.WriteStatusLog(logtext + "|" + "Error in function GetAttribute");
            }

            return sReturn;
        }
        private string FullpageOCRPath(String sValue)
        {
            try
            {
                if (sValue != null)
                {
                    if (sValue != "")
                    {
                        sValue = System.IO.Path.Combine(System.IO.Path.GetDirectoryName(sValue), "FullPage_" + System.IO.Path.GetFileName(sValue).ToUpper().Replace("FULLPAGE_", ""));
                    }
                }
                return sValue;
            }
            catch
            {
                return "";
            }
        }
        private string TemplateOCRPath(String sValue)
        {
            try
            {
                if (sValue != null)
                {
                    if (sValue != "")
                    {
                        sValue = System.IO.Path.Combine(System.IO.Path.GetDirectoryName(sValue), System.IO.Path.GetFileName(sValue).ToUpper().Replace("FULLPAGE_", ""));
                    }
                }
                return sValue;
            }
            catch
            {
                return "";
            }
        }

        private void GetXMLOutput(string Inputpath)
        {
            logtext = "GetXMLOutput  function inititated";
            trnsobj.WriteStatusLog(logtext);

            try
            {
                OutputXmlPath = Inputpath;
                ArryOFImageFile = System.IO.Directory.GetFiles(OutputXmlPath, "*.xml");
                //ViewState["ArrayData"] = ArryOFImageFile;

                PagePos = 0;

            }
            catch (Exception ex)
            {
                logtext = ex.Message.ToString();
                trnsobj.WriteStatusLog(logtext + "|" + "Error in GetXMLOutput function");
            }

        }
        private void FillBackColor(TextBox txtnode, Color BackColor, String Mode, XmlNode Node)
        {
            logtext = "FillBackColor function inititated";

            trnsobj.WriteStatusLog(logtext);

            try
            {
                ColorFlag = "false";
                XmlNode ModifyNode = Node.SelectSingleNode(@"//node()[@colname=""" + txtnode.ID + @"""]");
                String ModifyFlag = GetAttribute(ModifyNode, "modify");
                if (Mode.ToLower() == "enter")
                {
                    txtnode.BackColor = BackColor;
                }
                else
                {
                    if (ModifyFlag.ToLower() == "true")
                    {
                        //txtnode.Attributes.Add("style", "margin: 5px 0px;border: 1px solid rgb(142, 177, 212);text-indent: 5px; background-color: white;")
                        txtnode.BackColor = Color.LightYellow;//FromArgb(212, 202, 89);
                    }
                    else
                    {
                        //txtnode.BackColor = BackColor;
                        txtnode.Attributes.Add("style", "margin: 5px 0px;border: 1px solid rgb(142, 177, 212);text-indent: 5px; background-color: white;");
                    }
                    if (ModifyNode != null)
                    {
                        XmlNode ColorNode = ModifyNode.ParentNode;
                        if (ColorNode.Name.ToLower() == "header")
                            ColorNode = ModifyNode;
                        String sValidation = GetAttribute(ColorNode, "validation");
                        if (sValidation.ToLower() == "pass" && ViewMode.ToUpper() == "VERIFICATION")
                        {
                            ColorFlag = "true";
                            //txtnode.BackColor = Color.FromArgb(241, 187, 144);// Color.Bisque;
                            txtnode.Attributes.Add("style", "margin: 5px 0px;border: 1px solid rgb(142, 177, 212);text-indent: 5px; background-color: rgb(241, 187, 144);");
                        }
                    }

                }
            }
            catch (Exception ex)
            {
                logtext = ex.Message.ToString();
                trnsobj.WriteStatusLog(logtext + "|" + "Error in FillBackColor function");
            }


        }
        private void TextBoxProperty(TextBox DisplayData, XmlNode CurrentNode, String Mode)
        {
            logtext = "TextBoxProperty  function inititated";
            trnsobj.WriteStatusLog(logtext);

            try
            {
                SetAttribute(CurrentNode, "tabindex", TabIndex.ToString());
                SetAttribute(CurrentNode, "colname", DisplayData.ID);
                FillBackColor(DisplayData, Color.White, Mode, CurrentNode);

            }
            catch (Exception ex)
            {
                logtext = ex.Message.ToString();
                trnsobj.WriteStatusLog(logtext + "|" + "Error in TextBoxProperty function");
            }

        }
        public static void SetAttribute(XmlNode NewNode, String AttrName, String AttrValue)
        {
            try
            {
                XmlAttribute AttrNode = NewNode.OwnerDocument.CreateAttribute(AttrName);
                AttrNode.Value = AttrValue;
                NewNode.Attributes.Append(AttrNode);
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }

        }
        private void SetColor2Control(TextBox txtControl, Color SelectColor, Color FindColor, String Mode)
        {

            logtext = "SetColor2Control  function inititated";
            trnsobj.WriteStatusLog(logtext);
            try
            {

                XmlNode ControlNode = doc.SelectSingleNode(@"//node()[@colname=""" + txtControl.ID + @"""]");
                if (ControlNode != null)
                {
                    FillBackColor(txtControl, SelectColor, Mode, doc.DocumentElement);
                    if (ControlNode != null)
                    {
                        XmlNode parentNode = ControlNode.ParentNode;
                        if (parentNode != null)
                        {
                            if (parentNode.Name.ToLower() == "lineitems")
                            {
                                foreach (XmlNode ChildNode in parentNode.ChildNodes)
                                {
                                    Control ctrl = FindCtrl(GetAttribute(ChildNode, "colname"), txtControl);
                                    if (ctrl != null)
                                    {
                                        TextBox rtbCFindCrl = (TextBox)ctrl;
                                        if (rtbCFindCrl.BackColor != SelectColor)
                                            FillBackColor(rtbCFindCrl, FindColor, Mode, ChildNode);
                                    }
                                }
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                logtext = ex.Message.ToString();
                trnsobj.WriteStatusLog(logtext + "|" + "Error in SetColor2Control function");
            }

        }
        private Control FindCtrl(String CtrlName, TextBox txtControl)
        {
            Control ctrl = txtControl.Parent.FindControl(CtrlName);

            if (ctrl != null)
            {
                return ctrl;

            }
            else
                return null;

        }
        public static String GetAttribute(XmlNode SelectNode, String AttrName)
        {
            String sReturn = "";
            try
            {
                if (SelectNode != null)
                {

                    if (SelectNode.Attributes.GetNamedItem(AttrName) != null)
                    {
                        return SelectNode.Attributes.GetNamedItem(AttrName).Value;
                    }
                }
            }
            catch (Exception ex)
            {
                ex.Message.ToString();
            }
            return sReturn;
        }

        public void HideLineItemPanel()
        {
            //pnlLoadHeaderData.Attributes.Add("style", "height:380px;");
            //pnlLoadLineItemData.Attributes.Add("style", "display:none;");
        }

        private int Download_File(string CSVData)
        {
            logtext = "Download_File function initiated";
            trnsobj.WriteStatusLog(logtext);

            try
            {
                strBasePath = ConfigurationManager.AppSettings["BasePath"].ToString();
                string InputFileName = strBasePath;

                string attachment = "attachment; filename=" + Path.GetFileNameWithoutExtension(InputFileName) + ".csv";
                HttpContext.Response.Clear();
                HttpContext.Response.ClearHeaders();
                HttpContext.Response.ClearContent();
                HttpContext.Response.AddHeader("content-disposition", attachment);
                HttpContext.Response.ContentType = "text/csv";
                HttpContext.Response.Write(CSVData);
                Response.Flush();
                Response.Close();
                Response.End();
                return 0;
            }
            catch (System.Threading.ThreadAbortException exf)
            {
                return 0;
            }
            catch (Exception ex)
            {

                return -1;
            }
        }
        public static string FormatCSV(String input)
        {
            try
            {
                if (input == null)
                    return string.Empty;
                input = input.Replace(Environment.NewLine, " ");
                input = input.Replace("\n", " ").Replace("\r", " ");
                bool containsQuote = false;
                bool containsComma = false;
                int len = input.Length;
                for (int i = 0; i < len && (containsComma == false || containsQuote == false); i++)
                {
                    char ch = input[i];
                    if (ch == '"')
                        containsQuote = true;
                    else if (ch == ',')
                        containsComma = true;
                }

                if (containsQuote && containsComma)
                    input = input.Replace("\"", "\"\"");

                if (containsComma)
                    return "\"" + input + "\"";
                else
                    return input;
            }
            catch
            {
                throw;
            }
        }

        private void SetText2Xml(TextBox txtCtrl, XmlNode CurrentNode)
        {
            logtext = "SetText2Xml function initiated";
            trnsobj.WriteStatusLog(logtext);

            try
            {
                string sOldValue = CurrentNode.InnerText;
                CurrentNode.InnerText = txtCtrl.Text;

                SetAttribute(CurrentNode, "modify", "true");
                XmlNode ModifyNode = doc.SelectSingleNode("//modifyarea");

                CreateNewNode(CurrentNode.Name, sOldValue, ModifyNode, "append");
                CopyNode(CurrentNode, sOldValue, ModifyNode, "append");
            }
            catch (Exception ex)
            {

                logtext = ex.Message.ToString();
                trnsobj.WriteStatusLog(logtext + "|" + "Error in SetText2Xml function");
            }


        }

        public XmlNode CreateNewNode(String NodeName, String Text, XmlNode refNode, String CreateMethod)
        {
            logtext = "CreateNewNode function initiated";
            trnsobj.WriteStatusLog(logtext);

            XmlNode NewNode = null;
            try
            {

                if (refNode != null)
                {
                    NewNode = refNode.OwnerDocument.CreateElement(NodeName);
                    NewNode.InnerText = Text;
                    switch (CreateMethod.ToLower())
                    {
                        case "append":
                            refNode.AppendChild(NewNode);
                            break;
                        case "before":
                            if (refNode.ParentNode != null)
                                refNode.ParentNode.InsertBefore(NewNode, refNode);
                            else
                                refNode.AppendChild(NewNode);
                            break;
                        case "after":
                            if (refNode.ParentNode != null)
                                refNode.ParentNode.InsertAfter(NewNode, refNode);
                            else
                                refNode.AppendChild(NewNode);
                            break;
                        default:
                            refNode.AppendChild(NewNode);
                            break;
                    }

                }

            }
            catch (Exception ex)
            {
                logtext = ex.Message.ToString();
                trnsobj.WriteStatusLog(logtext + "|" + "Error in Createnewnode function");
            }
            return NewNode;
        }
        public XmlNode CopyNode(XmlNode CurrentNode, String Text, XmlNode refNode, String CreateMethod)
        {
            logtext = "CreateNewNode function initiated";
            trnsobj.WriteStatusLog(logtext);

            XmlNode NewNode = null;
            try
            {

                if (refNode != null)
                {
                    NewNode = CurrentNode.Clone();
                    NewNode.InnerText = Text;
                    switch (CreateMethod.ToLower())
                    {
                        case "append":
                            refNode.AppendChild(NewNode);
                            break;
                        case "before":
                            if (refNode.ParentNode != null)
                                refNode.ParentNode.InsertBefore(NewNode, refNode);
                            else
                                refNode.AppendChild(NewNode);
                            break;
                        case "after":
                            if (refNode.ParentNode != null)
                                refNode.ParentNode.InsertAfter(NewNode, refNode);
                            else
                                refNode.AppendChild(NewNode);
                            break;
                        default:
                            refNode.AppendChild(NewNode);
                            break;
                    }

                }

            }
            catch (Exception ex)
            {
                logtext = ex.Message.ToString();
                trnsobj.WriteStatusLog(logtext + "|" + "Error in Createnewnode function");
            }
            return NewNode;
        }
        private void SetText2Xml(TextBox rtbBox)
        {
            //ImageInfo imgInfo = (ImageInfo)rtbBox.Tag;
            //if(rtbBox.Text.Replace("\n", "").Replace("\r", "") != imgInfo.OrginalText.Replace("\n", "").Replace("\r", ""))
            //{
            //    XmlNode CurrentNode = GenericClass.PrePorcessDoc.SelectSingleNode(@"//node()[@colname=""" + rtbBox.Name + @"""]");
            //    if(CurrentNode != null)
            //    {
            //        CurrentNode.InnerText = rtbBox.Text;
            //        XmlNode ModifyNode = GenericClass.PrePorcessDoc.SelectSingleNode("//modifyarea");
            //        GenericClass.CreateNewNode(CurrentNode.Name, imgInfo.OrginalText, ModifyNode, "append");
            //        GenericClass.SetAttribute(CurrentNode, "modify", "true");
            //    }
            //}
        }

        private static byte[] ConvertFromBase64String(string input)
        {
            char[] charArr = input.ToCharArray();
            byte[] bytes = new byte[charArr.Length];
            for (int i = 0; i < charArr.Length; i++)
            {
                byte current = Convert.ToByte(charArr[i]);
                bytes[i] = current;
            }

            return bytes;
        }

        public string Base64ToXML(string base64File, string FileName, string FileExtension)
        {
            string retXml = "";
            try
            {
                string strImageName = string.Empty;
                string ImageName = FileName;
                string strInputPath = Path.Combine(Path.GetTempPath(), ImageName);
                string strOutputPath = Path.Combine(strInputPath, "XMLOutput");
                if (!Directory.Exists(strInputPath))
                {
                    Directory.CreateDirectory(strInputPath);
                }
                if (FileExtension.Contains("."))
                    strImageName = String.Concat(ImageName, FileExtension);
                else
                {
                    FileExtension = "." + FileExtension;
                    strImageName = String.Concat(ImageName, FileExtension);
                }
                var path = Path.Combine(strInputPath, strImageName);

                using (FileStream stream = System.IO.File.Create(path))
                {
                    Byte[] byteArray = Convert.FromBase64String(base64File);
                    //stream.Write(byteArray, 0, byteArray.Length);


                    retXml = System.Text.Encoding.UTF8.GetString(byteArray);
                }

                return retXml;
            }
            catch (Exception ex)
            {
                return retXml;
            }
        }

        private void ProcessXMLData(XmlNode oRootNode, string ProjectName)
        {
            try
            {
                XmlNodeList oNodeList = oRootNode.SelectNodes("//" + ProjectName);
                if (oNodeList.Count != 0)
                {

                    for (int nIndex = 0; nIndex < oNodeList.Count; nIndex++)
                    {
                        ////WriteMessage("Loop Count..." + nIndex, Color.Blue);
                        //XmlNode oSelectNode = oNodeList.Item(nIndex);
                        ////bsondline = new BsonDocument();
                        //result = AssignXMLProperty(oSelectNode.SelectSingleNode(".//_ItemNo"), "ItemNo", "line");
                        //result = AssignXMLProperty(oSelectNode.SelectSingleNode(".//_Description"), "Description", "line");
                        //result = AssignXMLProperty(oSelectNode.SelectSingleNode(".//_Quantity"), "Qty", "line");
                        //result = AssignXMLProperty(oSelectNode.SelectSingleNode(".//_UnitPrice"), "Rate", "line");
                        //result = AssignXMLProperty(oSelectNode.SelectSingleNode(".//_TaxAmount"), "TaxAmount", "line");
                        //result = AssignXMLProperty(oSelectNode.SelectSingleNode(".//_LineTotal"), "Total", "line");
                        //result = AssignXMLProperty(oSelectNode.SelectSingleNode(".//_Currency"), "Curr", "line");
                        //result = AssignXMLProperty(oSelectNode.SelectSingleNode(".//_ExRate"), "Ex-Rate", "line");
                        ////result = AssignXMLProperty(oRootNode.SelectSingleNode(".//_SNo"), "ItemNo");
                        //result = AssignXMLProperty(oSelectNode.SelectSingleNode(".//_Department"), "Dept", "line");
                        //result = AssignXMLProperty(oSelectNode.SelectSingleNode(".//_UOM"), "UOM", "line");
                        //result = AssignXMLProperty(oSelectNode.SelectSingleNode(".//_NetAmount"), "Amount", "line");

                        //WriteMessage("Adding bsondoc to bsondlist..." + nIndex, Color.Blue);
                        //oFRMOcr.WriteLog("Adding bsondoc to bsondlist..." + nIndex);
                        //bsonlinedoc.Add(bsonlineitem);
                    }
                }
            }
            catch (Exception ex)
            {

            }
        }
        private string AssignXMLProperty(XmlNode CurrentNode, string Name, string Type)
        {
            try
            {

                String Left = "";
                String Top = "";
                String Right = "";
                String Bottom = "";
                String InnerText = "";
                InnerText = GetInnerText(CurrentNode, Type);
                InnerText = InnerText.Replace("'", "''"); //Find innerText
                if (InnerText != "" && Type.ToLower() == "header" && Name.ToLower() != "destination")
                    NodeTextCount += 1;
                if (Type.ToLower() == "header" && Name.ToLower() != "destination")
                    NodeCount += 1;

                String URL = "http://www.abbyy.com/FlexiCapture/Schemas/Export/AdditionalFormData.xsd";
                String AttrName = "BlockRef";
                String RefVal = GetAttribute(CurrentNode, AttrName, URL);
                XmlNode SelectionNode = CurrentNode.SelectSingleNode(@"//addData:Blocks[@Id=""" + RefVal + @"""]//addData:Rect", xmlNameSpace);
                if (SelectionNode == null)
                {
                    URL = "http://www.abbyy.com/FlexiCapture/Schemas/Export/AdditionalFormData.xsd";
                    RefVal = GetAttribute(CurrentNode, AttrName, URL);
                    SelectionNode = CurrentNode.SelectSingleNode(@"//addData:Blocks[@Id=""" + RefVal + @"""]//addData:Rect", xmlNameSpace);

                }
                //Find Co-Ordinates
                if (SelectionNode != null)
                {
                    Left = GetAttribute(SelectionNode, "Left");
                    Top = GetAttribute(SelectionNode, "Top");
                    Right = GetAttribute(SelectionNode, "Right");
                    Bottom = GetAttribute(SelectionNode, "Bottom");
                }
                string Result = Left + "," + Top + "," + Right + "," + Bottom;

                //string res = BuildJson();
                return Result;
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }
        public static String GetAttributes(XmlNode SelectNode, String AttrName, String URL)
        {
            String sReturn = "";
            if (SelectNode != null)
            {

                if (SelectNode.Attributes.GetNamedItem(AttrName, URL) != null)
                {
                    return SelectNode.Attributes.GetNamedItem(AttrName, URL).Value;
                }
            }

            return sReturn;
        }
        public static String GetAttributes(XmlNode SelectNode, String AttrName)
        {

            String sReturn = "";
            if (SelectNode != null)
            {
                if (SelectNode.Attributes.GetNamedItem(AttrName) != null)
                {
                    return SelectNode.Attributes.GetNamedItem(AttrName).Value;
                }
            }

            return sReturn;
        }
        String GetInnerText(XmlNode oSelectNode, string Type)
        {
            String sResult = "";
            ConfidentScore = 0;
            if (oSelectNode != null)
            {
                sResult = oSelectNode.InnerText;//.Replace(Environment.NewLine, "&NewLine;").Replace(",", "&comma;");
                if (xmlDoc != null)
                {
                    XmlNode oConfidentScoreNode = xmlDoc.SelectSingleNode("//" + oSelectNode.Name.Replace("_", ""));
                    if (oConfidentScoreNode != null)
                    {
                        if (oConfidentScoreNode.Attributes.GetNamedItem("avgscore") != null)
                            float.TryParse(oConfidentScoreNode.Attributes.GetNamedItem("avgscore").Value.ToString(), out ConfidentScore);
                    }
                    if (Type.ToLower() == "header")
                        overallConf += ConfidentScore;
                }
            }
            return sResult;
        }
        private string BuildJson(OurTemplate ourTemplate)
        {
            string jsonString = "";
            try
            {


                //jsonString = ourTemplate.ToJSON();
                return jsonString;
            }
            catch (Exception ex)
            {
                return jsonString;
            }

        }

        public void WriteMessage(String sMessage, String sSubtext, Color oColor, int nPos)
        {


        }


        private DataTable getAnyTable()
        {
            DataTable dt = new DataTable("row");

            DataColumn dc;

            dc = new DataColumn();
            dc.ColumnName = "Status";//Status
            dc.DataType = System.Type.GetType("System.String");
            dt.Columns.Add(dc);

            dc = new DataColumn();
            dc.ColumnName = "ErrorCode";//ErrorCode
            dc.DataType = System.Type.GetType("System.String");
            dt.Columns.Add(dc);

            dc = new DataColumn();
            dc.ColumnName = "ErrorDescription";//ErrorDescription
            dc.DataType = System.Type.GetType("System.String");
            dt.Columns.Add(dc);

            dc = new DataColumn();
            dc.ColumnName = "ProductName";//ProductName
            dc.DataType = System.Type.GetType("System.String");
            dt.Columns.Add(dc);
            dc = new DataColumn();

            dc.ColumnName = "ProductIndicator";//ProductIndicator
            dc.DataType = System.Type.GetType("System.String");
            dt.Columns.Add(dc);
            return dt;
        }

        //public string RequestGetEligibleProducts(string state, string Occupation, DataSet objRes, string originalInceptionDate)
        //{
        //    try
        //    {
        //        string strBuildString = "<soap:Envelope xmlns:soap=\"http://www.w3.org/2003/05/soap-envelope\" xmlns:man=\"http://hxb30597.hiscox.nonprod/hsx/USDC_CallCentre_Gateway/WSProviders/manageCallCentreProvider\">";
        //        strBuildString += "<soap:Header />";
        //        strBuildString += "<soap:Body>";
        //        strBuildString += "<man:manageCallCentre>";
        //        strBuildString += "<ManageCallCentre>";
        //        strBuildString += "&lt;ManageCallCentre&gt;";
        //        strBuildString += "&lt;ApplicationArea&gt;";

        //        strBuildString += "&lt;MessageID&gt;" + objRes.Tables[0].Rows[0]["MessageID"].ToString() + "&lt;/MessageID&gt;";
        //        strBuildString += "&lt;TransmissionID&gt;" + objRes.Tables[0].Rows[0]["TransactionID"].ToString() + "&lt;/TransmissionID&gt;";
        //        strBuildString += "&lt;CreationDateTime&gt;" + objRes.Tables[0].Rows[0]["CreatedDate"].ToString() + "Z" + "&lt;/CreationDateTime&gt;";
        //        strBuildString += "&lt;Verb&gt;" + objRes.Tables[0].Rows[0]["Verb"].ToString() + "&lt;/Verb&gt;";
        //        strBuildString += "&lt;Noun&gt;" + objRes.Tables[0].Rows[0]["Noun"].ToString() + "&lt;/Noun&gt;";
        //        strBuildString += "&lt;SenderID&gt;" + objRes.Tables[0].Rows[0]["SendorID"].ToString() + "&lt;/SenderID&gt;";
        //        strBuildString += "&lt;UserArea operation=\"getEligibleProducts\" /&gt;";
        //        strBuildString += "&lt;/ApplicationArea&gt;";
        //        strBuildString += "&lt;DataArea&gt;";
        //        strBuildString += "&lt;Quote originalInceptionDate=\"" + getFormatedUKDate(originalInceptionDate) + "\"&gt;";
        //        strBuildString += "&lt;Client clientNumber=\"\" addressChangeIndicator=\"\" reference=\"\" clientRole=\"\"&gt;";
        //        strBuildString += "&lt;Company companyName=\"\" businessTitle=\"\" occupation=\"" + Occupation + "\" /&gt;";
        //        strBuildString += "&lt;AddressGBR addressID=\"\" postCode=\"\" address1=\"\" address2=\"\" address3=\"\" address4=\"\" county=\"\" address5=\"\" address6=\"\" state=\"" + state + "\" addressType=\"main\" country=\"\" cityTown=\"\" /&gt;";
        //        strBuildString += "&lt;/Client&gt;";
        //        strBuildString += "&lt;/Quote&gt;";
        //        strBuildString += "&lt;/DataArea&gt;";
        //        strBuildString += "&lt;/ManageCallCentre&gt;";
        //        strBuildString += "</ManageCallCentre>";
        //        strBuildString += "</man:manageCallCentre>";
        //        strBuildString += "</soap:Body>";
        //        strBuildString += "</soap:Envelope>";
        //        return strBuildString;
        //    }
        //    catch (Exception ex)
        //    {

        //        clsCommon.writeToFile("ServiceLayer", "getEligibleProducts", ex, SGSLogId);
        //    }
        //    return "";
        //} 

        #endregion

        #region OtherClasses

        /// <summary>
        /// Class XmlParser
        /// </summary>
        public static class XmlParser
        {
            /// <summary>
            /// Converts XML string to DataTable (BuildDataTableFromXml)
            /// </summary>
            /// <param name="Name">DataTable name</param>
            /// <param name="XMLString">XML string</param>
            /// <returns></returns>
            public static DataTable BuildDataTableFromXml(string Name, string XMLString)
            {
                XmlDocument doc = new XmlDocument();
                doc.Load(new StringReader(XMLString));
                DataTable Dt = new DataTable(Name);
                try
                {

                    XmlNode NodoExtract = doc.FirstChild.FirstChild;
                    //  Table structure (columns definition) 
                    foreach (XmlNode columns in NodoExtract.ChildNodes)
                    {
                        Dt.Columns.Add(columns.Name, typeof(String));
                    }

                    XmlNode Filas = doc.FirstChild;
                    //  Data Rows 
                    foreach (XmlNode Fila in Filas.ChildNodes)
                    {
                        List<string> Valores = new List<string>();
                        foreach (XmlNode Column in Fila.ChildNodes)
                        {
                            Valores.Add(Column.InnerText);
                        }
                        Dt.Rows.Add(Valores.ToArray());
                    }
                }
                catch (Exception)
                {

                }

                return Dt;
            }
        }

        public static class JSonObject
        {
            public static string XmlToJSON(string xml)
            {
                XmlDocument doc = new XmlDocument();
                //doc.LoadXml(xml);
                doc.Load(xml);

                return XmlToJSON(doc);
            }
            public static string XmlToJSON(XmlDocument xmlDoc)
            {
                StringBuilder sbJSON = new StringBuilder();
                sbJSON.Append("{ ");
                XmlToJSONnode(sbJSON, xmlDoc.DocumentElement, true);
                sbJSON.Append("}");
                return sbJSON.ToString();
            }

            //  XmlToJSONnode:  Output an XmlElement, possibly as part of a higher array
            private static void XmlToJSONnode(StringBuilder sbJSON, XmlElement node, bool showNodeName)
            {
                if (showNodeName)
                    sbJSON.Append("\"" + SafeJSON(node.Name) + "\": ");
                sbJSON.Append("{");
                // Build a sorted list of key-value pairs
                //  where   key is case-sensitive nodeName
                //          value is an ArrayList of string or XmlElement
                //  so that we know whether the nodeName is an array or not.
                SortedList<string, object> childNodeNames = new SortedList<string, object>();

                //  Add in all node attributes
                if (node.Attributes != null)
                    foreach (XmlAttribute attr in node.Attributes)
                        StoreChildNode(childNodeNames, attr.Name, attr.InnerText);

                //  Add in all nodes
                foreach (XmlNode cnode in node.ChildNodes)
                {
                    if (cnode is XmlText)
                        StoreChildNode(childNodeNames, "value", cnode.InnerText);
                    else if (cnode is XmlElement)
                        StoreChildNode(childNodeNames, cnode.Name, cnode);
                }

                // Now output all stored info
                foreach (string childname in childNodeNames.Keys)
                {
                    List<object> alChild = (List<object>)childNodeNames[childname];
                    if (alChild.Count == 1)
                        OutputNode(childname, alChild[0], sbJSON, true);
                    else
                    {
                        sbJSON.Append(" \"" + SafeJSON(childname) + "\": [ ");
                        foreach (object Child in alChild)
                            OutputNode(childname, Child, sbJSON, false);
                        sbJSON.Remove(sbJSON.Length - 2, 2);
                        sbJSON.Append(" ], ");
                    }
                }
                sbJSON.Remove(sbJSON.Length - 2, 2);
                sbJSON.Append(" }");
            }

            //  StoreChildNode: Store data associated with each nodeName
            //                  so that we know whether the nodeName is an array or not.
            private static void StoreChildNode(SortedList<string, object> childNodeNames, string nodeName, object nodeValue)
            {
                // Pre-process contraction of XmlElement-s
                if (nodeValue is XmlElement)
                {
                    // Convert  <aa></aa> into "aa":null
                    //          <aa>xx</aa> into "aa":"xx"
                    XmlNode cnode = (XmlNode)nodeValue;
                    if (cnode.Attributes.Count == 0)
                    {
                        XmlNodeList children = cnode.ChildNodes;
                        if (children.Count == 0)
                            nodeValue = null;
                        else if (children.Count == 1 && (children[0] is XmlText))
                            nodeValue = ((XmlText)(children[0])).InnerText;
                    }
                }
                // Add nodeValue to ArrayList associated with each nodeName
                // If nodeName doesn't exist then add it
                List<object> ValuesAL;

                if (childNodeNames.ContainsKey(nodeName))
                {
                    ValuesAL = (List<object>)childNodeNames[nodeName];
                }
                else
                {
                    ValuesAL = new List<object>();
                    childNodeNames[nodeName] = ValuesAL;
                }
                ValuesAL.Add(nodeValue);
            }

            private static void OutputNode(string childname, object alChild, StringBuilder sbJSON, bool showNodeName)
            {
                if (alChild == null)
                {
                    if (showNodeName)
                        sbJSON.Append("\"" + SafeJSON(childname) + "\": ");
                    sbJSON.Append("null");
                }
                else if (alChild is string)
                {
                    if (showNodeName)
                        sbJSON.Append("\"" + SafeJSON(childname) + "\": ");
                    string sChild = (string)alChild;
                    sChild = sChild.Trim();
                    sbJSON.Append("\"" + SafeJSON(sChild) + "\"");
                }
                else
                    XmlToJSONnode(sbJSON, (XmlElement)alChild, showNodeName);
                sbJSON.Append(", ");
            }

            // Make a string safe for JSON
            private static string SafeJSON(string sIn)
            {
                StringBuilder sbOut = new StringBuilder(sIn.Length);
                foreach (char ch in sIn)
                {
                    if (Char.IsControl(ch) || ch == '\'')
                    {
                        int ich = (int)ch;
                        sbOut.Append(@"\u" + ich.ToString("x4"));
                        continue;
                    }
                    else if (ch == '\"' || ch == '\\' || ch == '/')
                    {
                        sbOut.Append('\\');
                    }
                    sbOut.Append(ch);
                }
                return sbOut.ToString();
            }
        }

        public class XMLCustomConverter
        {
            public static T XmlToObject<T>(string xml)
            {
                using (var xmlStream = new StringReader(xml))
                {
                    var serializer = new XmlSerializer(typeof(T));
                    return (T)serializer.Deserialize(XmlReader.Create(xmlStream));
                }
            }

            public static List<T> XmlToObjectList<T>(string xml, string nodePath)
            {
                var xmlDocument = new XmlDocument();
                xmlDocument.LoadXml(xml);
                //xmlDocument.Load(xml);

                var returnItemsList = new List<T>();

                foreach (XmlNode xmlNode in xmlDocument.SelectNodes(nodePath))
                {
                    returnItemsList.Add(XmlToObject<T>(xmlNode.OuterXml));
                }
                return returnItemsList;
            }
        }

        public class OurTemplate
        {
            public int ID { get; set; }
            public string TemplateName { get; set; }
            public List<OurCoordinates> coordinateList { get; set; }
        }
        public class OurCoordinates
        {
            public int Id { get; set; }
            public int TemplateId { get; set; }
            public string CoordinateName { get; set; }
            public string FieldName { get; set; }
            public string FieldValue { get; set; }
            public decimal Left { get; set; }
            public decimal Right { get; set; }
            public decimal Top { get; set; }
            public decimal Bottom { get; set; }
        }

        //public static class StringXMLExtensions
        //{
        //    internal static XmlReader ToXmlReader(this string value)
        //    {
        //        var settings = new XmlReaderSettings { ConformanceLevel = ConformanceLevel.Fragment, IgnoreWhitespace = true, IgnoreComments = true };

        //        var xmlReader = XmlReader.Create(new StringReader(value), settings);
        //        xmlReader.Read();
        //        return xmlReader;
        //    }
        //}

        #endregion

    }
}